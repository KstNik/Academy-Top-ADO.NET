﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace Library {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }
        private void addBookButton_Click(object sender, EventArgs e) {
            using (LibraryModel1 db = new LibraryModel1()) {
                Book newBook = new Book {
                    Title = "Logics",
                    IdAuthor = 2,
                    Pages = 80,
                    Price = 35,
                    IdPublisher = 1
                };
                db.Book.Add(newBook);
                db.SaveChanges();
                booksDataGridView.DataSource = db.Book.Include("Author").Include("Publisher").ToList();
            }
        }
        private void editBookButton_Click(object sender, EventArgs e) {
            using (LibraryModel1 db = new LibraryModel1()) {
                var booksToUpdate = db.Book.Where(b => b.Id > 1000).ToList();
                foreach (var book in booksToUpdate)
                    book.Price = 89;
                db.SaveChanges();
                booksDataGridView.DataSource = db.Book.Include("Author").Include("Publisher").ToList();
            }
        }
        private void deleteBookButton_Click(object sender, EventArgs e) {
            using (LibraryModel1 db = new LibraryModel1()) {
                var booksToDelete = db.Book.Where(b => b.Id > 1000).ToList();
                foreach (var book in booksToDelete)
                    db.Book.Remove(book);
                db.SaveChanges();
                booksDataGridView.DataSource = db.Book.Include("Author").Include("Publisher").ToList();
            }
        }
        private void addAuthorButton_Click(object sender, EventArgs e) {
            using (LibraryModel1 db = new LibraryModel1()) {
                Author newAuthor = new Author {
                    FirstName = "David",
                    LastName = "Drake",
                };
                db.Author.Add(newAuthor);
                db.SaveChanges();
                authorsDataGridView.DataSource = db.Author.Include("Book").ToList();
            }
        }
        private void editAuthorButton_Click(object sender, EventArgs e) {
            using (LibraryModel1 db = new LibraryModel1()) {
                var authorsToUpdate = db.Author.Where(a => a.Id > 1000).ToList();
                foreach (var author in authorsToUpdate) {
                    author.FirstName = "Jack";
                    author.LastName = "Vance";
                }
                db.SaveChanges();
                authorsDataGridView.DataSource = db.Author.Include("Book").ToList();
            }
        }
        private void deleteAuthorButton_Click(object sender, EventArgs e) {
            using (LibraryModel1 db = new LibraryModel1()) {
                var authorsToDelete = db.Author.Where(a => a.Id > 1000).ToList();
                foreach (var author in authorsToDelete)
                    db.Author.Remove(author);
                db.SaveChanges();
                authorsDataGridView.DataSource = db.Author.Include("Book").ToList();
            }
        }
        private void addPublisherButton_Click(object sender, EventArgs e) {
            using (LibraryModel1 db = new LibraryModel1()) {
                Publisher newPublisher = new Publisher {
                    PublisherName = "Word",
                    Address = "Canada",
                };
                db.Publisher.Add(newPublisher);
                db.SaveChanges();
                publishersDataGridView.DataSource = db.Publisher.Include("Book").ToList();
            }
        }
        private void editPublisherButton_Click(object sender, EventArgs e) {
            using (LibraryModel1 db = new LibraryModel1()) {
                var publishersToUpdate = db.Publisher.Where(p => p.Id > 1000).ToList();
                foreach (var publisher in publishersToUpdate)
                    publisher.PublisherName = "Letter";
                db.SaveChanges();
                publishersDataGridView.DataSource = db.Publisher.Include("Book").ToList();
            }
        }
        private void deletePublisherButton_Click(object sender, EventArgs e) {
            using (LibraryModel1 db = new LibraryModel1()) {
                var publishersToDelete = db.Publisher.Where(p => p.Id > 1000).ToList();
                foreach (var publisher in publishersToDelete)
                    db.Publisher.Remove(publisher);
                db.SaveChanges();
                publishersDataGridView.DataSource = db.Publisher.Include("Book").ToList();
            }
        }
    }
}

/*I. Создание базы данных:
«Главное меню» -> «Вид» -> «Обозреватель объектов SQL Server» -> щелчок по узлу SQL Server -> 
щелчок по узлу (localdb)\MSSQLLocalDB -> «Базы данных» (щелчок правой кнопкой) -> 
«Добавить новую базу данных» -> изменить имя (указано ниже в [] после CREATE TABLE [dbo].) -> 
кнопка «OK» -> щелчок по узлу созданной базы -> «Таблицы» (щелчок правой кнопкой) -> «Добавить новую 
таблицу» -> вставить скрипт:
CREATE TABLE Author (
Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
FirstName VARCHAR(100) NOT NULL,
LastName VARCHAR(100) NOT NULL)
GO
CREATE TABLE Publisher (
Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
PublisherName VARCHAR(100) NOT NULL,
Address VARCHAR(100) NOT NULL)
GO
CREATE TABLE Book (
Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
Title VARCHAR(100) NOT NULL,
IdAuthor INT NOT NULL FOREIGN KEY REFERENCES
Author(Id),
Pages INT,
Price INT,
IdPublisher INT NOT NULL FOREIGN KEY
REFERENCES Publisher(Id))
GO
 -> кнопка «Обновить» -> кнопка «Обновить базу данных» -> щелчок правой кнопкой по созданной таблице -> 
«Просмотр данных» -> заполнить базу (при необходимости)
Пример заполнения (ЗАПОЛНЯТЬ НА АНГЛИЙСКОМ):
    Таблица "Author"
| Id |FirstName|LastName|
|  1 |  Jack   | London |
|  2 |  Isaac  | Asimov |
    Таблица "Publisher"
| Id |PublisherName|Address|
|  1 |    Books    |  USA  |
|  2 |    World    |  UK   |
    Таблица "Book"
| Id |  Title  |IdAuthor|Pages|Price|IdPublisher|
|  1 | Road    |    1   |  70 |  25 |     1     |
|  2 | Robbie  |    2   |  85 |  32 |     2     |
Примечание: Если «Вид» не содержит «Обозреватель объектов SQL Server»: в «Обозревателе 
решений» щелчок правой кнопкой по наименованию проекта -> «Добавить» -> «Создать элемент …» -> 
«База данных, основанная на службах» -> кнопка «Добавить»

II. Создание класса:
Пункт меню «Проект» (https://learn.microsoft.com/ru-ru/nuget/consume-packages/install-use-packages-visual-studio) -> 
подпункт «Управление пакетами NuGet…» -> в открывшейся вкладке «NuGet: …» выбрать пункт меню «Обзор» -> 
в строке поиска заполнить Entity Framework -> в левом окне выбрать EntityFramework (БЕЗ Core!!!) -> 
в правом окне нажать кнопку «Установить» -> в появившемся диалоговом окне «Просмотр изменений» нажать 
кнопку «OK»
В окне «Обозреватель решений» щелчок правой кнопкой по наименованию проекта -> в контекстном меню выбрать 
пункт «Добавить» -> пункт меню «Компонент» -> в появившемся окне выбрать «Модель ADO.NET EDM» (проще по 
поиску: EDM) -> поле «Имя» изменить: LibraryModel1-> нажать кнопку «Добавить» -> в появившемся окне выбрать 
«Конструктор EF из базы данных» -> нажать кнопку «Далее» -> в появившемся окне нажать кнопку «Создать 
соединение» -> в появившемся окне поле «Источник данных»: Microsoft SQL Server (SqlClient) (оставить без 
изменений) -> в поле: «Имя сервера» внести: (localdb)\MSSQLLocalDB -> нажать кнопку «Обновить» -> в поле 
«Введите или выберите имя базы данных» выбрать: Library -> нажать кнопку «OK» -> нажать кнопку «Далее» -> 
в появившемся окне отобразится структура БД -> левой кнопкой раскрыть узел таблиц и отметить чекбоксы 
возле каждой из таблиц БД -> нажать кнопку «Готово»*/

/*Задание: Создайте Windows Forms приложение для работы с нашей БД с использованием Entity Framework по 
технологии Database First. В главном окне приложения должен содержаться элемент TabControl с тремя 
вкладками: Books, Authors и Publishers. Каждая вкладка должна обслуживать одну из таблиц нашей БД и 
выполнять добавление, удаление и редактирование записей в своей таблице. Для добавления, редактирования 
и удаления записей использовать формы. Для отображения результатов методов GetAllAuthors(), GetAllBooks() 
и GetAllPublishers() использовать DataGridView.*/