﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.deleteBookButton = new System.Windows.Forms.Button();
            this.editBookButton = new System.Windows.Forms.Button();
            this.addBookButton = new System.Windows.Forms.Button();
            this.booksDataGridView = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.deleteAuthorButton = new System.Windows.Forms.Button();
            this.editAuthorButton = new System.Windows.Forms.Button();
            this.addAuthorButton = new System.Windows.Forms.Button();
            this.authorsDataGridView = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.deletePublisherButton = new System.Windows.Forms.Button();
            this.editPublisherButton = new System.Windows.Forms.Button();
            this.addPublisherButton = new System.Windows.Forms.Button();
            this.publishersDataGridView = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.booksDataGridView)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.authorsDataGridView)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.publishersDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 426);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.deleteBookButton);
            this.tabPage1.Controls.Add(this.editBookButton);
            this.tabPage1.Controls.Add(this.addBookButton);
            this.tabPage1.Controls.Add(this.booksDataGridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 400);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Books";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // deleteBookButton
            // 
            this.deleteBookButton.Location = new System.Drawing.Point(168, 6);
            this.deleteBookButton.Name = "deleteBookButton";
            this.deleteBookButton.Size = new System.Drawing.Size(75, 23);
            this.deleteBookButton.TabIndex = 3;
            this.deleteBookButton.Text = "DeleteBook";
            this.deleteBookButton.UseVisualStyleBackColor = true;
            this.deleteBookButton.Click += new System.EventHandler(this.deleteBookButton_Click);
            // 
            // editBookButton
            // 
            this.editBookButton.Location = new System.Drawing.Point(87, 6);
            this.editBookButton.Name = "editBookButton";
            this.editBookButton.Size = new System.Drawing.Size(75, 23);
            this.editBookButton.TabIndex = 2;
            this.editBookButton.Text = "EditBook";
            this.editBookButton.UseVisualStyleBackColor = true;
            this.editBookButton.Click += new System.EventHandler(this.editBookButton_Click);
            // 
            // addBookButton
            // 
            this.addBookButton.Location = new System.Drawing.Point(6, 6);
            this.addBookButton.Name = "addBookButton";
            this.addBookButton.Size = new System.Drawing.Size(75, 23);
            this.addBookButton.TabIndex = 1;
            this.addBookButton.Text = "AddBook";
            this.addBookButton.UseVisualStyleBackColor = true;
            this.addBookButton.Click += new System.EventHandler(this.addBookButton_Click);
            // 
            // booksDataGridView
            // 
            this.booksDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.booksDataGridView.Location = new System.Drawing.Point(3, 38);
            this.booksDataGridView.Name = "booksDataGridView";
            this.booksDataGridView.Size = new System.Drawing.Size(762, 362);
            this.booksDataGridView.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.deleteAuthorButton);
            this.tabPage2.Controls.Add(this.editAuthorButton);
            this.tabPage2.Controls.Add(this.addAuthorButton);
            this.tabPage2.Controls.Add(this.authorsDataGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 400);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Authors";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // deleteAuthorButton
            // 
            this.deleteAuthorButton.Location = new System.Drawing.Point(168, 6);
            this.deleteAuthorButton.Name = "deleteAuthorButton";
            this.deleteAuthorButton.Size = new System.Drawing.Size(75, 23);
            this.deleteAuthorButton.TabIndex = 3;
            this.deleteAuthorButton.Text = "DeleteAuthorButton";
            this.deleteAuthorButton.UseVisualStyleBackColor = true;
            this.deleteAuthorButton.Click += new System.EventHandler(this.deleteAuthorButton_Click);
            // 
            // editAuthorButton
            // 
            this.editAuthorButton.Location = new System.Drawing.Point(87, 6);
            this.editAuthorButton.Name = "editAuthorButton";
            this.editAuthorButton.Size = new System.Drawing.Size(75, 23);
            this.editAuthorButton.TabIndex = 2;
            this.editAuthorButton.Text = "EditAuthor";
            this.editAuthorButton.UseVisualStyleBackColor = true;
            this.editAuthorButton.Click += new System.EventHandler(this.editAuthorButton_Click);
            // 
            // addAuthorButton
            // 
            this.addAuthorButton.Location = new System.Drawing.Point(6, 6);
            this.addAuthorButton.Name = "addAuthorButton";
            this.addAuthorButton.Size = new System.Drawing.Size(75, 23);
            this.addAuthorButton.TabIndex = 1;
            this.addAuthorButton.Text = "AddAuthor";
            this.addAuthorButton.UseVisualStyleBackColor = true;
            this.addAuthorButton.Click += new System.EventHandler(this.addAuthorButton_Click);
            // 
            // authorsDataGridView
            // 
            this.authorsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.authorsDataGridView.Location = new System.Drawing.Point(3, 38);
            this.authorsDataGridView.Name = "authorsDataGridView";
            this.authorsDataGridView.Size = new System.Drawing.Size(762, 362);
            this.authorsDataGridView.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.deletePublisherButton);
            this.tabPage3.Controls.Add(this.editPublisherButton);
            this.tabPage3.Controls.Add(this.addPublisherButton);
            this.tabPage3.Controls.Add(this.publishersDataGridView);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(768, 400);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Publishers";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // deletePublisherButton
            // 
            this.deletePublisherButton.Location = new System.Drawing.Point(168, 6);
            this.deletePublisherButton.Name = "deletePublisherButton";
            this.deletePublisherButton.Size = new System.Drawing.Size(75, 23);
            this.deletePublisherButton.TabIndex = 3;
            this.deletePublisherButton.Text = "DeletePublisher";
            this.deletePublisherButton.UseVisualStyleBackColor = true;
            this.deletePublisherButton.Click += new System.EventHandler(this.deletePublisherButton_Click);
            // 
            // editPublisherButton
            // 
            this.editPublisherButton.Location = new System.Drawing.Point(87, 6);
            this.editPublisherButton.Name = "editPublisherButton";
            this.editPublisherButton.Size = new System.Drawing.Size(75, 23);
            this.editPublisherButton.TabIndex = 2;
            this.editPublisherButton.Text = "EditPublisher";
            this.editPublisherButton.UseVisualStyleBackColor = true;
            this.editPublisherButton.Click += new System.EventHandler(this.editPublisherButton_Click);
            // 
            // addPublisherButton
            // 
            this.addPublisherButton.Location = new System.Drawing.Point(6, 6);
            this.addPublisherButton.Name = "addPublisherButton";
            this.addPublisherButton.Size = new System.Drawing.Size(75, 23);
            this.addPublisherButton.TabIndex = 1;
            this.addPublisherButton.Text = "AddPublisher";
            this.addPublisherButton.UseVisualStyleBackColor = true;
            this.addPublisherButton.Click += new System.EventHandler(this.addPublisherButton_Click);
            // 
            // publishersDataGridView
            // 
            this.publishersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.publishersDataGridView.Location = new System.Drawing.Point(3, 38);
            this.publishersDataGridView.Name = "publishersDataGridView";
            this.publishersDataGridView.Size = new System.Drawing.Size(762, 362);
            this.publishersDataGridView.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.booksDataGridView)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.authorsDataGridView)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.publishersDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView booksDataGridView;
        private System.Windows.Forms.DataGridView authorsDataGridView;
        private System.Windows.Forms.DataGridView publishersDataGridView;
        private System.Windows.Forms.Button deleteBookButton;
        private System.Windows.Forms.Button editBookButton;
        private System.Windows.Forms.Button addBookButton;
        private System.Windows.Forms.Button deleteAuthorButton;
        private System.Windows.Forms.Button editAuthorButton;
        private System.Windows.Forms.Button addAuthorButton;
        private System.Windows.Forms.Button deletePublisherButton;
        private System.Windows.Forms.Button editPublisherButton;
        private System.Windows.Forms.Button addPublisherButton;
    }
}

