﻿using AdoNetSample4.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;
using System.Configuration;/* !ПО УМОЛЧАНИЮ НЕ ПОДКЛЮЧАЕТСЯ, порядок подключения:
в «Обозревателе решений» щелчок правой кнопкой по узлу «Ссылки» -> «Добавить ссылку…» -> 
выбрать в списке «System.Configuration» -> поставить «галочку» -> нажать кнопку «OK»*/

namespace AdoNetSample4 {
    public partial class Form1 : Form {
        DbConnection conn = null;
        DbProviderFactory fact = null;
        string connectionString = "";
        public Form1() {
            InitializeComponent();
            button1.Enabled = false;
        }
        private async void
        button1_Click(object sender, EventArgs e) {
            conn.ConnectionString = connectionString;
            await conn.OpenAsync();
            DbCommand comm = conn.CreateCommand();
            comm.CommandText = "WAITFOR DELAY '00:00:05';";
            comm.CommandText += textBox1.Text.ToString();
            DataTable table = new DataTable();
            using (DbDataReader reader = await comm.ExecuteReaderAsync()) {
                int line = 0;
                do {
                    while (await reader.ReadAsync()) {
                        if (line == 0) {
                            for (int i = 0; i < reader.FieldCount; i++) {
                                table.Columns.Add(reader.
                                GetName(i));
                            }
                            line++;
                        }
                        DataRow row = table.NewRow();
                        for (int i = 0; i < reader.FieldCount; i++) {
                            row[i] = await reader.
                            GetFieldValueAsync<Object>(i);
                        }
                        table.Rows.Add(row);
                    }
                } while (reader.NextResult());
            }
            // выводим результаты запроса
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = table;
            if (textBox1.Text.Trim().ToUpper() == "SELECT * FROM VEGETABLESFRUITS")
                FillComboBoxWithColors(table);
            else {
                comboBoxColors.Items.Clear();
                comboBoxColors.Enabled = false;
                labelCount.Text = "";
            }
        }
        ///<summary>
        ///При загрузке окна выбираем фабрику для поставщика System.Data.SqlClient вызываем
        ///метод для получения строки подключения из конфигурациооного файла
        ///</summary>
        ///<param name="sender"></param>
        ///<param name="e"></param>
        private void Form1Load(object sender, EventArgs e) {
            fact = DbProviderFactories.
            GetFactory("System.Data.SqlClient");
            conn = fact.CreateConnection();
            connectionString = GetConnectionStringByProvider("System.Data.SqlClient");
            if (connectionString == null)
                MessageBox.Show("В конфигурационном файле нет требуемой строки подключения");
        }
        ///<summary>
        ///Этот метод по имени поставщика данных считывает из конфигурационного файла
        ///и возвращает строку подключения, если эта строка есть в конфигурационном файле:)
        ///</summary>
        ///<param name="providerName"></param>
        ///<returns></returns>
        static string GetConnectionStringByProvider(string providerName) {
            string returnValue = null;
            // читаем все строки подключения из App.config
            ConnectionStringSettingsCollection settings = ConfigurationManager.ConnectionStrings;
            // ищем и возвращаем строку подключения
            if (settings != null) {
                foreach (ConnectionStringSettings cs in settings) {
                    if (cs.ProviderName == providerName) {
                        returnValue = cs.ConnectionString;
                        break;
                    }
                }
            }
            return returnValue;
        }
        ///<summary>
        ///управление доступностью кнопки
        ///</summary>
        ///<param name="sender"></param>
        ///<param name="e"></param>
        void textBox1_TextChanged(object sender, EventArgs e) {
            if (textBox1.Text.Length > 3)
                button1.Enabled = true;
            else
                button1.Enabled = false;
        }
        private void comboBoxColors_SelectedIndexChanged(object sender, EventArgs e) {
            string selectedColor = comboBoxColors.SelectedItem as string;
            if (selectedColor != null) {
                int count = GetFruitsAndVegetablesCountByColor(selectedColor);
                labelCount.Text = $"Количество: {count}";
            }
        }
        private int GetFruitsAndVegetablesCountByColor(string color) {
            using (DataTable table = (DataTable)dataGridView1.DataSource) {
                if (table != null)
                    return table.AsEnumerable().Count(row => row.Field<string>("Color") == color);
            }
            return 0;
        }
        private void FillComboBoxWithColors(DataTable table) {
            comboBoxColors.Items.Clear();
            comboBoxColors.Enabled = true;
            var colors = table.AsEnumerable().Select(row => row.Field<string>("Color")).Distinct();
            foreach (var color in colors)
                comboBoxColors.Items.Add(color);
        }
    }
}

/*Создание базы данных:
«Главное меню» -> «Вид» -> «Обозреватель объектов SQL Server» -> щелчок по узлу SQL Server -> 
щелчок по узлу (localdb)\MSSQLLocalDB -> «Базы данных» (щелчок правой кнопкой) -> 
«Добавить новую базу данных» -> изменить имя (указано ниже в [] после CREATE TABLE [dbo].) -> 
кнопка «OK» -> щелчок по узлу созданной базы -> «Таблицы» (щелчок правой кнопкой) -> «Добавить новую 
таблицу» -> вставить скрипт:
CREATE TABLE [dbo].[VegetablesFruits] (
    [Id]       INT           IDENTITY (1, 1) NOT NULL,
    [Name]     NVARCHAR (50) NOT NULL,
    [Type]     NVARCHAR (50) NOT NULL,
    [Color]    NVARCHAR (50) NOT NULL,
    [Calories] INT           DEFAULT ((100)) NOT NULL
);
 -> кнопка «Обновить» -> кнопка «Обновить базу данных» -> щелчок правой кнопкой по созданной таблице -> 
«Просмотр данных» -> заполнить базу (при необходимости)
ДЛЯ КОРРЕКТНОГО ОТОБРАЖЕНИЯ В КОНСОЛИ КОЛИЧЕСТВО СИМВОЛОВ В ЯЧЕЙКЕ НЕ ДОЛЖНО ПРЕВЫШАТЬ 7!!!
Пример заполнения:
| Id |  Name  |  Type  | Color  |Calories|
|  1 | Томат  | Овощ   | Красный|   25   |
|  2 | Банан  | Фрукт  | Жёлтый |   89   |
|  3 | Лимон  | Фрукт  | Жёлтый |   29   |
|  4 | Огурец | Овощ   | Зелёный|   14   |
|  5 | Слива  | Фрукт  | Синий  |   46   |
|  6 | Яблоко | Фрукт  | Красный|   52   |

Примечание: Если «Вид» не содержит «Обозреватель объектов SQL Server»: в «Обозревателе 
решений» щелчок правой кнопкой по наименованию проекта -> «Добавить» -> «Создать элемент …» -> 
«База данных, основанная на службах» -> кнопка «Добавить»*/

/*Задание
В качестве домашнего задания вам надо доработать приложение LibraryTest4 из этого урока. На главное окно приложения 
надо добавить комбобокс и метку для отображения небольших числовых значений. Логику работы приложения надо изменить 
таким образом, чтобы при выполнении запроса «select * from books» результаты выполнения этого запроса, как и раньше, 
отображались бы в DataGridView. При этом одновременно должен заполняться комбобокс, куда должны заноситься имена 
авторов, книги которых есть в таблице Books. При выборе в комбобоксе какого-либо автора, в добавленной метке должно 
отображаться количество книг выбранного автора в таблице Books.
Комбобокс должен заполняться только в том случае, когда пользователь ввёл в окно единственный запрос «select * from 
books». Без уточнения полей, без каких-либо условий, без других запросов. При вводе любых других запросов, комбобокс 
должен оставаться пустым.
Заполнение комбобокса именами авторов и заполнение метки количеством книг должны выполняться асинхронно 
с использованием async и await.
При желании, выполнить для любой другой базы данных, не меняя принцип работы, изложенный выше.*/