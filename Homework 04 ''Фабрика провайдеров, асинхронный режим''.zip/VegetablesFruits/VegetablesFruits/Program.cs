﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;/* !ПО УМОЛЧАНИЮ НЕ ПОДКЛЮЧАЕТСЯ, порядок подключения:
в «Обозревателе решений» щелчок правой кнопкой по узлу «Ссылки» -> «Добавить ссылку…» -> 
выбрать в списке «System.Configuration» -> поставить «галочку» -> нажать кнопку «OK»*/

namespace VegetablesFruits {
    class Program {
        string cs = "";
        DbProviderFactory factory = null;
        DbConnection conn = null;
        public Program() {
            Console.WriteLine("\n  Выберите базу данных: ");
            Console.WriteLine("  1. SQL");
            Console.WriteLine("  2. Access");
            Console.Write("  ");
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice) {
                case 1:
                    factory = SqlClientFactory.Instance;
                    conn = factory.CreateConnection();
                    cs = ConfigurationManager.ConnectionStrings["SQLConnection"].ConnectionString;
                    conn.ConnectionString = cs;
                    break;
                case 2:
                    factory = System.Data.OleDb.OleDbFactory.Instance;
                    conn = factory.CreateConnection();
                    cs = ConfigurationManager.ConnectionStrings["AccessConnection"].ConnectionString;
                    conn.ConnectionString = cs;
                    break;
                default:
                    Console.WriteLine("  Некорректный выбор");
                    return;
            }
        }
        static async Task Main(string[] args) {
            Console.WriteLine("\n\tФАБРИКА ПРОВАЙДЕРОВ, АСИНХРОННЫЙ РЕЖИМ");
            Program pr = new Program();
            await pr.ReadDataAsync();
        }
        public async Task ReadDataAsync() {
            DbDataReader rdr = null;
            int num = -1;
            String[] str = { "Добавление данных", "Изменение данных", "Удаление данных" };
            try {
                await conn.OpenAsync(); // открытие соединения асинхронно
                Console.WriteLine("\n  Соединение с сервером установлено");
                DbCommand cmd = conn.CreateCommand();
                cmd.CommandText = "INSERT INTO VegetablesFruits ([Name], [Type], [Color], [Calories]) " +
                    "VALUES (N'Груша', N'Фрукт', N'Зелёный', 100) SELECT * FROM VegetablesFruits; " +
                    "UPDATE VegetablesFruits SET [Calories] = 57 WHERE [Id] > 1000 SELECT * FROM VegetablesFruits; " +
                    "DELETE FROM VegetablesFruits WHERE [Id] > 1000 SELECT * FROM VegetablesFruits";
                rdr = await cmd.ExecuteReaderAsync(); // асинхронное выполнение команды и получение DataReader
                int line; // извлечение полученных строк
                do {
                    var startTime = DateTime.Now; // засечка времени до выполнения
                    num++;
                    Console.WriteLine("\n" + "\t" + (num + 1) + ". " + str[num]);
                    line = 0;
                    while (await rdr.ReadAsync()) { // асинхронное чтение данных
                        if (line == 0)
                        { // формирование шапки таблицы перед выводом первой строки
                            Console.Write("  ");
                            for (int i = 0; i < rdr.FieldCount; i++) // цикл по числу прочитанных полей
                                Console.Write(rdr.GetName(i).ToString() + "\t"); // вывод в консольное окно имён полей
                            Console.WriteLine();
                        }
                        line++;
                        Console.WriteLine("  " + rdr[0] + "\t" + rdr[1] + "\t" + rdr[2] + "\t" + rdr[3] + "\t"
                            + rdr[4]);
                    }
                    Console.WriteLine("  Обработано строк: " + line.ToString());
                    var endTime = DateTime.Now; // вывод времени, затраченного на выполнение
                    var elapsedTime = endTime - startTime;
                    Console.WriteLine("  Время выполнения: " + elapsedTime.TotalMilliseconds + " мс");
                } while (await rdr.NextResultAsync()); // переход к следующему результату
            }
            catch (Exception ex) {
                Console.WriteLine("  Ошибка: " + ex.Message);
            }
            finally {
                if (rdr != null) // закрытие reader
                    rdr.Close();
                if (conn.State == ConnectionState.Open) // проверка на открытое соединение
                    conn.Close();
            }

            Console.Write("\n  Для выхода нажмите любую клавишу ");
            Console.ReadKey();
        }
    }
}

/*Создание базы данных:
«Главное меню» -> «Вид» -> «Обозреватель объектов SQL Server» -> щелчок по узлу SQL Server -> 
щелчок по узлу (localdb)\MSSQLLocalDB -> «Базы данных» (щелчок правой кнопкой) -> 
«Добавить новую базу данных» -> изменить имя (указано ниже в [] после CREATE TABLE [dbo].) -> 
кнопка «OK» -> щелчок по узлу созданной базы -> «Таблицы» (щелчок правой кнопкой) -> «Добавить 
новую таблицу» -> вставить скрипт:
CREATE TABLE [dbo].[VegetablesFruits] (
    [Id]       INT           IDENTITY (1, 1) NOT NULL,
    [Name]     NVARCHAR (50) NOT NULL,
    [Type]     NVARCHAR (50) NOT NULL,
    [Color]    NVARCHAR (50) NOT NULL,
    [Calories] INT           DEFAULT ((100)) NOT NULL
);
 -> кнопка «Обновить» -> кнопка «Обновить базу данных» -> щелчок правой кнопкой по созданной таблице -> 
«Просмотр данных» -> заполнить базу (при необходимости)
ДЛЯ КОРРЕКТНОГО ОТОБРАЖЕНИЯ В КОНСОЛИ КОЛИЧЕСТВО СИМВОЛОВ В ЯЧЕЙКЕ НЕ ДОЛЖНО ПРЕВЫШАТЬ 7!!!
Пример заполнения:
| Id |  Name  |  Type  | Color  |Calories|
|  1 | Томат  | Овощ   | Красный|   25   |
|  2 | Банан  | Фрукт  | Жёлтый |   89   |
|  3 | Лимон  | Фрукт  | Жёлтый |   29   |
|  4 | Огурец | Овощ   | Зелёный|   14   |
|  5 | Слива  | Фрукт  | Синий  |   46   |
|  6 | Яблоко | Фрукт  | Красный|   52   |

Примечание: Если «Вид» не содержит «Обозреватель объектов SQL Server»: в «Обозревателе 
решений» щелчок правой кнопкой по наименованию проекта -> «Добавить» -> «Создать элемент …» -> 
«База данных, основанная на службах» -> кнопка «Добавить»*/