﻿using System;
using System.Linq;
using System.Data.SqlClient;

namespace VegetablesFruitsLINQ {
    class Program {
        static void Main(string[] args) {

            Console.WriteLine("\n\t\tLINQ");

            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=VegetablesFruits;
                Integrated Security=SSPI;Encrypt=False";
                /*Обязательно добавить в строку подключения Encrypt=False, иначе компилятор выдаст сообщение: 
                System.Data.SqlClient.SqlException: "Экземпляр SQL Server, к которому устанавливалось подключение, 
                не поддерживает шифрования."*/
            using (var db = new DataClasses1DataContext(connectionString)) {
                Console.WriteLine("\n  1. Отображение всей информации:");
                var allItems = db.VegetablesFruits;
                foreach (var item in allItems)
                    Console.WriteLine($"     {item.Id}, {item.Name}, {item.Type}, {item.Color}, {item.Calories}");
                Console.WriteLine("\n  2. Отображение всех названий:");
                var allNames = db.VegetablesFruits.Select(x => x.Name);
                foreach (var name in allNames)
                    Console.WriteLine("     " + name);
                Console.WriteLine("\n  3. Отображение всех цветов:");
                var allColors = db.VegetablesFruits.Select(x => x.Color).Distinct();
                foreach (var colors in allColors)
                    Console.WriteLine("     " + colors);
                Console.WriteLine("\n  4. Максимальная калорийность:");
                var maxCalories = db.VegetablesFruits.Max(x => x.Calories);
                Console.WriteLine("     " + maxCalories);
                Console.WriteLine("\n  5. Минимальная калорийность:");
                var minCalories = db.VegetablesFruits.Min(x => x.Calories);
                Console.WriteLine("     " + minCalories);
                Console.WriteLine("\n  6. Средняя калорийность:");
                var avgCalories = db.VegetablesFruits.Average(x => x.Calories);
                Console.WriteLine("     " + avgCalories);
                Console.WriteLine("\n  7. Количество овощей:");
                var vegetableCount = db.VegetablesFruits.Count(x => x.Type == "Овощ");
                Console.WriteLine("     " + vegetableCount);
                Console.WriteLine("\n  8. Количество фруктов:");
                var fruitCount = db.VegetablesFruits.Count(x => x.Type == "Фрукт");
                Console.WriteLine("     " + fruitCount);
                Console.WriteLine("\n  9. Количество овощей и фруктов красного цвета:");
                var color = "Красный";
                var colorCount = db.VegetablesFruits.Count(x => x.Color == color);
                Console.WriteLine("     " + colorCount);
                Console.WriteLine("\n  A. Количество овощей и фруктов каждого цвета:");
                var countByColor = db.VegetablesFruits.GroupBy(x => x.Color)
                    .Select(g => new { Color = g.Key, Count = g.Count() });
                foreach (var item in countByColor)
                    Console.WriteLine($"     {item.Color}: {item.Count}");
                Console.WriteLine("\n  B. Калорийность ниже средней:");
                var maxCal = avgCalories;
                var lowCalItems = db.VegetablesFruits.Where(x => x.Calories < maxCal);
                foreach (var item in lowCalItems)
                    Console.WriteLine($"     {item.Name}, {item.Calories}");
                Console.WriteLine("\n  C. Калорийность выше средней:");
                var minCal = avgCalories;
                var highCalItems = db.VegetablesFruits.Where(x => x.Calories > minCal);
                foreach (var item in highCalItems)
                    Console.WriteLine($"     {item.Name}, {item.Calories}");
                Console.WriteLine("\n  D. Калорийность между min и max:");
                var rangeLow = minCalories;
                var rangeHigh = maxCalories;
                var rangeCalItems = db.VegetablesFruits.Where(x => x.Calories > rangeLow && x.Calories < rangeHigh);
                foreach (var item in rangeCalItems)
                    Console.WriteLine($"     {item.Name}, {item.Calories}");
                Console.WriteLine("\n  E. Жёлтые или красные:");
                var yellowOrRed = new[] { "Жёлтый", "Красный" };
                var yellowRedItems = db.VegetablesFruits.Where(x => yellowOrRed.Contains(x.Color));
                foreach (var item in yellowRedItems)
                    Console.WriteLine($"     {item.Name}, {item.Color}");

                Console.Write("\n  Для выхода нажмите любую клавишу ");
                Console.ReadKey();
            }
        }
    }
}

/*I. Создание базы данных:
«Главное меню» -> «Вид» -> «Обозреватель объектов SQL Server» -> щелчок по узлу SQL Server -> 
щелчок по узлу (localdb)\MSSQLLocalDB -> «Базы данных» (щелчок правой кнопкой) -> 
«Добавить новую базу данных» -> изменить имя (указано ниже в [] после CREATE TABLE [dbo].) -> 
кнопка «OK» -> щелчок по узлу созданной базы -> «Таблицы» (щелчок правой кнопкой) -> «Добавить новую 
таблицу» -> вставить скрипт:
CREATE TABLE [dbo].[VegetablesFruits] (
    [Id]       INT           IDENTITY (1, 1) NOT NULL,
    [Name]     NVARCHAR (50) NOT NULL,
    [Type]     NVARCHAR (50) NOT NULL,
    [Color]    NVARCHAR (50) NOT NULL,
    [Calories] INT           DEFAULT ((100)) NOT NULL
);
 -> кнопка «Обновить» -> кнопка «Обновить базу данных» -> щелчок правой кнопкой по созданной таблице -> 
«Просмотр данных» -> заполнить базу (при необходимости)
ДЛЯ КОРРЕКТНОГО ОТОБРАЖЕНИЯ В КОНСОЛИ КОЛИЧЕСТВО СИМВОЛОВ В ЯЧЕЙКЕ НЕ ДОЛЖНО ПРЕВЫШАТЬ 7!!!
Пример заполнения:
| Id |  Name  |  Type  | Color  |Calories|
|  1 | Томат  | Овощ   | Красный|   25   |
|  2 | Банан  | Фрукт  | Жёлтый |   89   |
|  3 | Лимон  | Фрукт  | Жёлтый |   29   |
|  4 | Огурец | Овощ   | Зелёный|   14   |
|  5 | Слива  | Фрукт  | Синий  |   46   |
|  6 | Яблоко | Фрукт  | Красный|   52   |

Примечание: Если «Вид» не содержит «Обозреватель объектов SQL Server»: в «Обозревателе 
решений» щелчок правой кнопкой по наименованию проекта -> «Добавить» -> «Создать элемент …» -> 
«База данных, основанная на службах» -> кнопка «Добавить»

II. Установка соединения: 
«Главное меню» -> «Вид» -> «Обозреватель серверов» -> щелчок по опции «Подключение данных» -> в контекстном меню 
выбрать «Добавить подключение…» -> поле «Источник данных» должно содержать: Microsoft SQL Server (SqlClient), 
в поле «Имя сервера» внести: (localdb)\MSSQLLocalDB -> в поле «Выберите или введите имя базы данных» выбрать: 
VegetablesFruits -> нажать кнопку «OK»

III. Создание класса:
Запустить программу «Visual Studio Installer» (находится в папке вместе с Visual Studio) -> пункт меню «Установленные 
продукты» -> выбрать «Visual Studio Community 2022» -> нажать кнопку справа «Изменить» -> выбрать пункт меню 
«Отдельные компоненты» -> найти «Инструменты LINQ to SQL» с помощью полосы прокрутки или по поиску, поставить 
«галочку» напротив него -> нажать кнопку «Изменить» (СООТВЕТСТВЕННО – ЕСЛИ «ГАЛОЧКА» (ФЛАЖОК) УЖЕ ЕСТЬ КНОПКУ 
«ИЗМЕНИТЬ» НАЖИМАТЬ НЕ НАДО, Т.К. КОМПОНЕНТ УСТАНОВЛЕН!)
В окне «Обозреватель решений» щелчок правой кнопкой по наименованию проекта -> в контекстном меню выбрать пункт 
«Добавить» -> пункт меню «Компонент» -> выбрать «Классы LINQ to SQL» (проще по поиску: LINQ) -> нажать кнопку 
«Добавить» -> в главном окне появиться новая вкладка «DataClasses1.dbml»
Перейти в «Обозреватель серверов» -> правой кнопкой раскрыть узел созданного подключения -> раскрыть узел базы 
данных «VegetablesFruits» -> раскрыть узел «Таблицы» -> сбросить таблицу «VegetablesFruits» на элемент 
«DataClasses1.dbml» (ЕСЛИ БАЗА ДАННЫХ, НАПРИМЕР, СОДЕРЖИТ НЕСКОЛЬКО ТАБЛИЦ, ТО ОНИ ВСЕ ПЕРЕБРАСЫВАЮТСЯ ПО ОЧЕРЕДИ!)*/