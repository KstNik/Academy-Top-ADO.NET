﻿namespace BookStore
{
  partial class Form2
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.button1 = new System.Windows.Forms.Button();
      this.comboBox1 = new System.Windows.Forms.ComboBox();
      this.comboBox2 = new System.Windows.Forms.ComboBox();
      this.button2 = new System.Windows.Forms.Button();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.dataGridView1 = new System.Windows.Forms.DataGridView();
      this.tabControl1 = new System.Windows.Forms.TabControl();
      this.tabPage1 = new System.Windows.Forms.TabPage();
      this.button4 = new System.Windows.Forms.Button();
      this.label21 = new System.Windows.Forms.Label();
      this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
      this.textBox3 = new System.Windows.Forms.TextBox();
      this.label12 = new System.Windows.Forms.Label();
      this.label20 = new System.Windows.Forms.Label();
      this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
      this.comboBox11 = new System.Windows.Forms.ComboBox();
      this.label13 = new System.Windows.Forms.Label();
      this.label19 = new System.Windows.Forms.Label();
      this.maskedTextBox4 = new System.Windows.Forms.MaskedTextBox();
      this.comboBox10 = new System.Windows.Forms.ComboBox();
      this.label14 = new System.Windows.Forms.Label();
      this.label18 = new System.Windows.Forms.Label();
      this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
      this.comboBox9 = new System.Windows.Forms.ComboBox();
      this.label15 = new System.Windows.Forms.Label();
      this.label17 = new System.Windows.Forms.Label();
      this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
      this.comboBox8 = new System.Windows.Forms.ComboBox();
      this.label16 = new System.Windows.Forms.Label();
      this.tabPage2 = new System.Windows.Forms.TabPage();
      this.button3 = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.comboBox3 = new System.Windows.Forms.ComboBox();
      this.tabPage3 = new System.Windows.Forms.TabPage();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.button5 = new System.Windows.Forms.Button();
      this.label3 = new System.Windows.Forms.Label();
      this.label22 = new System.Windows.Forms.Label();
      this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
      this.comboBox12 = new System.Windows.Forms.ComboBox();
      this.textBox2 = new System.Windows.Forms.TextBox();
      this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
      this.label4 = new System.Windows.Forms.Label();
      this.label11 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.label10 = new System.Windows.Forms.Label();
      this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
      this.comboBox7 = new System.Windows.Forms.ComboBox();
      this.comboBox5 = new System.Windows.Forms.ComboBox();
      this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
      this.label6 = new System.Windows.Forms.Label();
      this.label9 = new System.Windows.Forms.Label();
      this.label7 = new System.Windows.Forms.Label();
      this.label8 = new System.Windows.Forms.Label();
      this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
      this.comboBox6 = new System.Windows.Forms.ComboBox();
      this.label2 = new System.Windows.Forms.Label();
      this.comboBox4 = new System.Windows.Forms.ComboBox();
      this.tabPage4 = new System.Windows.Forms.TabPage();
      this.textBox7 = new System.Windows.Forms.TextBox();
      this.label38 = new System.Windows.Forms.Label();
      this.textBox6 = new System.Windows.Forms.TextBox();
      this.label37 = new System.Windows.Forms.Label();
      this.label36 = new System.Windows.Forms.Label();
      this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
      this.textBox5 = new System.Windows.Forms.TextBox();
      this.label34 = new System.Windows.Forms.Label();
      this.label33 = new System.Windows.Forms.Label();
      this.comboBox18 = new System.Windows.Forms.ComboBox();
      this.label32 = new System.Windows.Forms.Label();
      this.comboBox17 = new System.Windows.Forms.ComboBox();
      this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
      this.label24 = new System.Windows.Forms.Label();
      this.button6 = new System.Windows.Forms.Button();
      this.label23 = new System.Windows.Forms.Label();
      this.comboBox13 = new System.Windows.Forms.ComboBox();
      this.tabPage5 = new System.Windows.Forms.TabPage();
      this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
      this.label25 = new System.Windows.Forms.Label();
      this.button7 = new System.Windows.Forms.Button();
      this.label26 = new System.Windows.Forms.Label();
      this.comboBox14 = new System.Windows.Forms.ComboBox();
      this.tabPage6 = new System.Windows.Forms.TabPage();
      this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
      this.label29 = new System.Windows.Forms.Label();
      this.label28 = new System.Windows.Forms.Label();
      this.textBox4 = new System.Windows.Forms.TextBox();
      this.button8 = new System.Windows.Forms.Button();
      this.label27 = new System.Windows.Forms.Label();
      this.comboBox15 = new System.Windows.Forms.ComboBox();
      this.tabPage7 = new System.Windows.Forms.TabPage();
      this.label35 = new System.Windows.Forms.Label();
      this.comboBox19 = new System.Windows.Forms.ComboBox();
      this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
      this.label30 = new System.Windows.Forms.Label();
      this.button9 = new System.Windows.Forms.Button();
      this.label31 = new System.Windows.Forms.Label();
      this.comboBox16 = new System.Windows.Forms.ComboBox();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
      this.tabControl1.SuspendLayout();
      this.tabPage1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
      this.tabPage2.SuspendLayout();
      this.tabPage3.SuspendLayout();
      this.groupBox3.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
      this.tabPage4.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
      this.tabPage5.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
      this.tabPage6.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
      this.tabPage7.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
      this.SuspendLayout();
      // 
      // textBox1
      // 
      this.textBox1.Location = new System.Drawing.Point(10, 32);
      this.textBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(268, 20);
      this.textBox1.TabIndex = 0;
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(377, 29);
      this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(60, 24);
      this.button1.TabIndex = 1;
      this.button1.Text = "Найти";
      this.button1.UseVisualStyleBackColor = true;
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // comboBox1
      // 
      this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox1.FormattingEnabled = true;
      this.comboBox1.Location = new System.Drawing.Point(281, 31);
      this.comboBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox1.Name = "comboBox1";
      this.comboBox1.Size = new System.Drawing.Size(94, 21);
      this.comboBox1.TabIndex = 2;
      // 
      // comboBox2
      // 
      this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox2.FormattingEnabled = true;
      this.comboBox2.Location = new System.Drawing.Point(10, 31);
      this.comboBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox2.Name = "comboBox2";
      this.comboBox2.Size = new System.Drawing.Size(352, 21);
      this.comboBox2.TabIndex = 3;
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(366, 27);
      this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(71, 23);
      this.button2.TabIndex = 4;
      this.button2.Text = "Показать";
      this.button2.UseVisualStyleBackColor = true;
      this.button2.Click += new System.EventHandler(this.button2_Click);
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.comboBox2);
      this.groupBox1.Controls.Add(this.button2);
      this.groupBox1.Location = new System.Drawing.Point(21, 14);
      this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.groupBox1.Size = new System.Drawing.Size(444, 62);
      this.groupBox1.TabIndex = 5;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Параметры выборки";
      this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.textBox1);
      this.groupBox2.Controls.Add(this.button1);
      this.groupBox2.Controls.Add(this.comboBox1);
      this.groupBox2.Location = new System.Drawing.Point(21, 108);
      this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.groupBox2.Size = new System.Drawing.Size(444, 65);
      this.groupBox2.TabIndex = 6;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Параметры поиска";
      // 
      // dataGridView1
      // 
      this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dataGridView1.Location = new System.Drawing.Point(21, 209);
      this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.dataGridView1.Name = "dataGridView1";
      this.dataGridView1.RowHeadersWidth = 62;
      this.dataGridView1.RowTemplate.Height = 28;
      this.dataGridView1.Size = new System.Drawing.Size(444, 211);
      this.dataGridView1.TabIndex = 7;
      // 
      // tabControl1
      // 
      this.tabControl1.Controls.Add(this.tabPage1);
      this.tabControl1.Controls.Add(this.tabPage2);
      this.tabControl1.Controls.Add(this.tabPage3);
      this.tabControl1.Controls.Add(this.tabPage4);
      this.tabControl1.Controls.Add(this.tabPage5);
      this.tabControl1.Controls.Add(this.tabPage6);
      this.tabControl1.Controls.Add(this.tabPage7);
      this.tabControl1.Location = new System.Drawing.Point(495, 14);
      this.tabControl1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.tabControl1.Name = "tabControl1";
      this.tabControl1.SelectedIndex = 0;
      this.tabControl1.Size = new System.Drawing.Size(325, 406);
      this.tabControl1.TabIndex = 11;
      // 
      // tabPage1
      // 
      this.tabPage1.Controls.Add(this.button4);
      this.tabPage1.Controls.Add(this.label21);
      this.tabPage1.Controls.Add(this.numericUpDown3);
      this.tabPage1.Controls.Add(this.textBox3);
      this.tabPage1.Controls.Add(this.label12);
      this.tabPage1.Controls.Add(this.label20);
      this.tabPage1.Controls.Add(this.maskedTextBox3);
      this.tabPage1.Controls.Add(this.comboBox11);
      this.tabPage1.Controls.Add(this.label13);
      this.tabPage1.Controls.Add(this.label19);
      this.tabPage1.Controls.Add(this.maskedTextBox4);
      this.tabPage1.Controls.Add(this.comboBox10);
      this.tabPage1.Controls.Add(this.label14);
      this.tabPage1.Controls.Add(this.label18);
      this.tabPage1.Controls.Add(this.dateTimePicker2);
      this.tabPage1.Controls.Add(this.comboBox9);
      this.tabPage1.Controls.Add(this.label15);
      this.tabPage1.Controls.Add(this.label17);
      this.tabPage1.Controls.Add(this.numericUpDown4);
      this.tabPage1.Controls.Add(this.comboBox8);
      this.tabPage1.Controls.Add(this.label16);
      this.tabPage1.Location = new System.Drawing.Point(4, 22);
      this.tabPage1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.tabPage1.Name = "tabPage1";
      this.tabPage1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.tabPage1.Size = new System.Drawing.Size(317, 380);
      this.tabPage1.TabIndex = 0;
      this.tabPage1.Text = "Добавить";
      this.tabPage1.UseVisualStyleBackColor = true;
      // 
      // button4
      // 
      this.button4.Location = new System.Drawing.Point(52, 315);
      this.button4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.button4.Name = "button4";
      this.button4.Size = new System.Drawing.Size(227, 25);
      this.button4.TabIndex = 20;
      this.button4.Text = "Сохранить";
      this.button4.UseVisualStyleBackColor = true;
      this.button4.Click += new System.EventHandler(this.button4_Click);
      // 
      // label21
      // 
      this.label21.AutoSize = true;
      this.label21.Location = new System.Drawing.Point(47, 30);
      this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label21.Name = "label21";
      this.label21.Size = new System.Drawing.Size(57, 13);
      this.label21.TabIndex = 1;
      this.label21.Text = "Название";
      // 
      // numericUpDown3
      // 
      this.numericUpDown3.Location = new System.Drawing.Point(141, 225);
      this.numericUpDown3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.numericUpDown3.Name = "numericUpDown3";
      this.numericUpDown3.Size = new System.Drawing.Size(138, 20);
      this.numericUpDown3.TabIndex = 19;
      // 
      // textBox3
      // 
      this.textBox3.Location = new System.Drawing.Point(107, 26);
      this.textBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.textBox3.Name = "textBox3";
      this.textBox3.Size = new System.Drawing.Size(173, 20);
      this.textBox3.TabIndex = 0;
      // 
      // label12
      // 
      this.label12.AutoSize = true;
      this.label12.Location = new System.Drawing.Point(49, 226);
      this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label12.Name = "label12";
      this.label12.Size = new System.Drawing.Size(66, 13);
      this.label12.TabIndex = 18;
      this.label12.Text = "Количество";
      // 
      // label20
      // 
      this.label20.AutoSize = true;
      this.label20.Location = new System.Drawing.Point(48, 57);
      this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label20.Name = "label20";
      this.label20.Size = new System.Drawing.Size(37, 13);
      this.label20.TabIndex = 2;
      this.label20.Text = "Автор";
      // 
      // maskedTextBox3
      // 
      this.maskedTextBox3.Location = new System.Drawing.Point(141, 276);
      this.maskedTextBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.maskedTextBox3.Mask = "0000.00";
      this.maskedTextBox3.Name = "maskedTextBox3";
      this.maskedTextBox3.Size = new System.Drawing.Size(73, 20);
      this.maskedTextBox3.TabIndex = 17;
      // 
      // comboBox11
      // 
      this.comboBox11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox11.FormattingEnabled = true;
      this.comboBox11.Location = new System.Drawing.Point(107, 52);
      this.comboBox11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox11.Name = "comboBox11";
      this.comboBox11.Size = new System.Drawing.Size(173, 21);
      this.comboBox11.TabIndex = 3;
      // 
      // label13
      // 
      this.label13.AutoSize = true;
      this.label13.Location = new System.Drawing.Point(49, 276);
      this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label13.Name = "label13";
      this.label13.Size = new System.Drawing.Size(80, 13);
      this.label13.TabIndex = 16;
      this.label13.Text = "Цена продажи";
      // 
      // label19
      // 
      this.label19.AutoSize = true;
      this.label19.Location = new System.Drawing.Point(45, 86);
      this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label19.Name = "label19";
      this.label19.Size = new System.Drawing.Size(56, 13);
      this.label19.TabIndex = 4;
      this.label19.Text = "Издатель";
      // 
      // maskedTextBox4
      // 
      this.maskedTextBox4.Location = new System.Drawing.Point(141, 248);
      this.maskedTextBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.maskedTextBox4.Mask = "0000.00";
      this.maskedTextBox4.Name = "maskedTextBox4";
      this.maskedTextBox4.Size = new System.Drawing.Size(73, 20);
      this.maskedTextBox4.TabIndex = 15;
      // 
      // comboBox10
      // 
      this.comboBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox10.FormattingEnabled = true;
      this.comboBox10.Location = new System.Drawing.Point(107, 81);
      this.comboBox10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox10.Name = "comboBox10";
      this.comboBox10.Size = new System.Drawing.Size(173, 21);
      this.comboBox10.TabIndex = 5;
      // 
      // label14
      // 
      this.label14.AutoSize = true;
      this.label14.Location = new System.Drawing.Point(49, 248);
      this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label14.Name = "label14";
      this.label14.Size = new System.Drawing.Size(86, 13);
      this.label14.TabIndex = 14;
      this.label14.Text = "Себестоимость";
      // 
      // label18
      // 
      this.label18.AutoSize = true;
      this.label18.Location = new System.Drawing.Point(48, 116);
      this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label18.Name = "label18";
      this.label18.Size = new System.Drawing.Size(36, 13);
      this.label18.TabIndex = 6;
      this.label18.Text = "Жанр";
      // 
      // dateTimePicker2
      // 
      this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dateTimePicker2.Location = new System.Drawing.Point(141, 200);
      this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.dateTimePicker2.Name = "dateTimePicker2";
      this.dateTimePicker2.Size = new System.Drawing.Size(139, 20);
      this.dateTimePicker2.TabIndex = 13;
      // 
      // comboBox9
      // 
      this.comboBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox9.FormattingEnabled = true;
      this.comboBox9.Location = new System.Drawing.Point(107, 110);
      this.comboBox9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox9.Name = "comboBox9";
      this.comboBox9.Size = new System.Drawing.Size(173, 21);
      this.comboBox9.TabIndex = 7;
      // 
      // label15
      // 
      this.label15.AutoSize = true;
      this.label15.Location = new System.Drawing.Point(48, 200);
      this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label15.Name = "label15";
      this.label15.Size = new System.Drawing.Size(78, 13);
      this.label15.TabIndex = 12;
      this.label15.Text = "Дата издания";
      // 
      // label17
      // 
      this.label17.AutoSize = true;
      this.label17.Location = new System.Drawing.Point(48, 143);
      this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label17.Name = "label17";
      this.label17.Size = new System.Drawing.Size(91, 13);
      this.label17.TabIndex = 8;
      this.label17.Text = "Продолжение от";
      // 
      // numericUpDown4
      // 
      this.numericUpDown4.Location = new System.Drawing.Point(141, 168);
      this.numericUpDown4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.numericUpDown4.Name = "numericUpDown4";
      this.numericUpDown4.Size = new System.Drawing.Size(138, 20);
      this.numericUpDown4.TabIndex = 11;
      // 
      // comboBox8
      // 
      this.comboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox8.FormattingEnabled = true;
      this.comboBox8.Location = new System.Drawing.Point(141, 141);
      this.comboBox8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox8.Name = "comboBox8";
      this.comboBox8.Size = new System.Drawing.Size(139, 21);
      this.comboBox8.TabIndex = 9;
      // 
      // label16
      // 
      this.label16.AutoSize = true;
      this.label16.Location = new System.Drawing.Point(48, 170);
      this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label16.Name = "label16";
      this.label16.Size = new System.Drawing.Size(49, 13);
      this.label16.TabIndex = 10;
      this.label16.Text = "Страниц";
      // 
      // tabPage2
      // 
      this.tabPage2.Controls.Add(this.button3);
      this.tabPage2.Controls.Add(this.label1);
      this.tabPage2.Controls.Add(this.comboBox3);
      this.tabPage2.Location = new System.Drawing.Point(4, 22);
      this.tabPage2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.tabPage2.Name = "tabPage2";
      this.tabPage2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.tabPage2.Size = new System.Drawing.Size(317, 380);
      this.tabPage2.TabIndex = 1;
      this.tabPage2.Text = "Удалить";
      this.tabPage2.UseVisualStyleBackColor = true;
      // 
      // button3
      // 
      this.button3.Location = new System.Drawing.Point(45, 114);
      this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(230, 19);
      this.button3.TabIndex = 2;
      this.button3.Text = "Удалить";
      this.button3.UseVisualStyleBackColor = true;
      this.button3.Click += new System.EventHandler(this.button3_Click);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(43, 72);
      this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(37, 13);
      this.label1.TabIndex = 1;
      this.label1.Text = "Книга";
      // 
      // comboBox3
      // 
      this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox3.FormattingEnabled = true;
      this.comboBox3.Location = new System.Drawing.Point(82, 70);
      this.comboBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox3.Name = "comboBox3";
      this.comboBox3.Size = new System.Drawing.Size(195, 21);
      this.comboBox3.TabIndex = 0;
      // 
      // tabPage3
      // 
      this.tabPage3.Controls.Add(this.groupBox3);
      this.tabPage3.Controls.Add(this.label2);
      this.tabPage3.Controls.Add(this.comboBox4);
      this.tabPage3.Location = new System.Drawing.Point(4, 22);
      this.tabPage3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.tabPage3.Name = "tabPage3";
      this.tabPage3.Size = new System.Drawing.Size(317, 380);
      this.tabPage3.TabIndex = 2;
      this.tabPage3.Text = "Редактировать";
      this.tabPage3.UseVisualStyleBackColor = true;
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.Add(this.button5);
      this.groupBox3.Controls.Add(this.label3);
      this.groupBox3.Controls.Add(this.label22);
      this.groupBox3.Controls.Add(this.numericUpDown1);
      this.groupBox3.Controls.Add(this.comboBox12);
      this.groupBox3.Controls.Add(this.textBox2);
      this.groupBox3.Controls.Add(this.numericUpDown2);
      this.groupBox3.Controls.Add(this.label4);
      this.groupBox3.Controls.Add(this.label11);
      this.groupBox3.Controls.Add(this.label5);
      this.groupBox3.Controls.Add(this.label10);
      this.groupBox3.Controls.Add(this.maskedTextBox1);
      this.groupBox3.Controls.Add(this.comboBox7);
      this.groupBox3.Controls.Add(this.comboBox5);
      this.groupBox3.Controls.Add(this.dateTimePicker1);
      this.groupBox3.Controls.Add(this.label6);
      this.groupBox3.Controls.Add(this.label9);
      this.groupBox3.Controls.Add(this.label7);
      this.groupBox3.Controls.Add(this.label8);
      this.groupBox3.Controls.Add(this.maskedTextBox2);
      this.groupBox3.Controls.Add(this.comboBox6);
      this.groupBox3.Location = new System.Drawing.Point(9, 42);
      this.groupBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.groupBox3.Size = new System.Drawing.Size(301, 333);
      this.groupBox3.TabIndex = 12;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Редактировать";
      // 
      // button5
      // 
      this.button5.Location = new System.Drawing.Point(26, 302);
      this.button5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.button5.Name = "button5";
      this.button5.Size = new System.Drawing.Size(227, 25);
      this.button5.TabIndex = 41;
      this.button5.Text = "Сохранить";
      this.button5.UseVisualStyleBackColor = true;
      this.button5.Click += new System.EventHandler(this.button5_Click);
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(23, 29);
      this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(57, 13);
      this.label3.TabIndex = 22;
      this.label3.Text = "Название";
      // 
      // label22
      // 
      this.label22.AutoSize = true;
      this.label22.Location = new System.Drawing.Point(25, 168);
      this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label22.Name = "label22";
      this.label22.Size = new System.Drawing.Size(49, 13);
      this.label22.TabIndex = 31;
      this.label22.Text = "Страниц";
      // 
      // numericUpDown1
      // 
      this.numericUpDown1.Location = new System.Drawing.Point(117, 224);
      this.numericUpDown1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.numericUpDown1.Name = "numericUpDown1";
      this.numericUpDown1.Size = new System.Drawing.Size(138, 20);
      this.numericUpDown1.TabIndex = 40;
      // 
      // comboBox12
      // 
      this.comboBox12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox12.FormattingEnabled = true;
      this.comboBox12.Location = new System.Drawing.Point(117, 140);
      this.comboBox12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox12.Name = "comboBox12";
      this.comboBox12.Size = new System.Drawing.Size(139, 21);
      this.comboBox12.TabIndex = 30;
      // 
      // textBox2
      // 
      this.textBox2.Location = new System.Drawing.Point(84, 25);
      this.textBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.textBox2.Name = "textBox2";
      this.textBox2.Size = new System.Drawing.Size(173, 20);
      this.textBox2.TabIndex = 21;
      // 
      // numericUpDown2
      // 
      this.numericUpDown2.Location = new System.Drawing.Point(117, 167);
      this.numericUpDown2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.numericUpDown2.Name = "numericUpDown2";
      this.numericUpDown2.Size = new System.Drawing.Size(138, 20);
      this.numericUpDown2.TabIndex = 32;
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(26, 225);
      this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(66, 13);
      this.label4.TabIndex = 39;
      this.label4.Text = "Количество";
      // 
      // label11
      // 
      this.label11.AutoSize = true;
      this.label11.Location = new System.Drawing.Point(25, 142);
      this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label11.Name = "label11";
      this.label11.Size = new System.Drawing.Size(91, 13);
      this.label11.TabIndex = 29;
      this.label11.Text = "Продолжение от";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(25, 56);
      this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(37, 13);
      this.label5.TabIndex = 23;
      this.label5.Text = "Автор";
      // 
      // label10
      // 
      this.label10.AutoSize = true;
      this.label10.Location = new System.Drawing.Point(25, 198);
      this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label10.Name = "label10";
      this.label10.Size = new System.Drawing.Size(78, 13);
      this.label10.TabIndex = 33;
      this.label10.Text = "Дата издания";
      // 
      // maskedTextBox1
      // 
      this.maskedTextBox1.Location = new System.Drawing.Point(117, 274);
      this.maskedTextBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.maskedTextBox1.Mask = "0000.00";
      this.maskedTextBox1.Name = "maskedTextBox1";
      this.maskedTextBox1.Size = new System.Drawing.Size(73, 20);
      this.maskedTextBox1.TabIndex = 38;
      // 
      // comboBox7
      // 
      this.comboBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox7.FormattingEnabled = true;
      this.comboBox7.Location = new System.Drawing.Point(84, 109);
      this.comboBox7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox7.Name = "comboBox7";
      this.comboBox7.Size = new System.Drawing.Size(173, 21);
      this.comboBox7.TabIndex = 28;
      // 
      // comboBox5
      // 
      this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox5.FormattingEnabled = true;
      this.comboBox5.Location = new System.Drawing.Point(84, 51);
      this.comboBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox5.Name = "comboBox5";
      this.comboBox5.Size = new System.Drawing.Size(173, 21);
      this.comboBox5.TabIndex = 24;
      // 
      // dateTimePicker1
      // 
      this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dateTimePicker1.Location = new System.Drawing.Point(117, 198);
      this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.dateTimePicker1.Name = "dateTimePicker1";
      this.dateTimePicker1.Size = new System.Drawing.Size(139, 20);
      this.dateTimePicker1.TabIndex = 34;
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(26, 274);
      this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(80, 13);
      this.label6.TabIndex = 37;
      this.label6.Text = "Цена продажи";
      // 
      // label9
      // 
      this.label9.AutoSize = true;
      this.label9.Location = new System.Drawing.Point(25, 114);
      this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size(36, 13);
      this.label9.TabIndex = 27;
      this.label9.Text = "Жанр";
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Location = new System.Drawing.Point(22, 85);
      this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(56, 13);
      this.label7.TabIndex = 25;
      this.label7.Text = "Издатель";
      // 
      // label8
      // 
      this.label8.AutoSize = true;
      this.label8.Location = new System.Drawing.Point(26, 246);
      this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(86, 13);
      this.label8.TabIndex = 35;
      this.label8.Text = "Себестоимость";
      // 
      // maskedTextBox2
      // 
      this.maskedTextBox2.Location = new System.Drawing.Point(117, 246);
      this.maskedTextBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.maskedTextBox2.Mask = "0000.00";
      this.maskedTextBox2.Name = "maskedTextBox2";
      this.maskedTextBox2.Size = new System.Drawing.Size(73, 20);
      this.maskedTextBox2.TabIndex = 36;
      // 
      // comboBox6
      // 
      this.comboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox6.FormattingEnabled = true;
      this.comboBox6.Location = new System.Drawing.Point(84, 80);
      this.comboBox6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox6.Name = "comboBox6";
      this.comboBox6.Size = new System.Drawing.Size(173, 21);
      this.comboBox6.TabIndex = 26;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(47, 18);
      this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(37, 13);
      this.label2.TabIndex = 2;
      this.label2.Text = "Книга";
      // 
      // comboBox4
      // 
      this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox4.FormattingEnabled = true;
      this.comboBox4.Location = new System.Drawing.Point(92, 16);
      this.comboBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox4.Name = "comboBox4";
      this.comboBox4.Size = new System.Drawing.Size(195, 21);
      this.comboBox4.TabIndex = 1;
      this.comboBox4.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
      // 
      // tabPage4
      // 
      this.tabPage4.Controls.Add(this.textBox7);
      this.tabPage4.Controls.Add(this.label38);
      this.tabPage4.Controls.Add(this.textBox6);
      this.tabPage4.Controls.Add(this.label37);
      this.tabPage4.Controls.Add(this.label36);
      this.tabPage4.Controls.Add(this.dateTimePicker3);
      this.tabPage4.Controls.Add(this.textBox5);
      this.tabPage4.Controls.Add(this.label34);
      this.tabPage4.Controls.Add(this.label33);
      this.tabPage4.Controls.Add(this.comboBox18);
      this.tabPage4.Controls.Add(this.label32);
      this.tabPage4.Controls.Add(this.comboBox17);
      this.tabPage4.Controls.Add(this.numericUpDown5);
      this.tabPage4.Controls.Add(this.label24);
      this.tabPage4.Controls.Add(this.button6);
      this.tabPage4.Controls.Add(this.label23);
      this.tabPage4.Controls.Add(this.comboBox13);
      this.tabPage4.Location = new System.Drawing.Point(4, 22);
      this.tabPage4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.tabPage4.Name = "tabPage4";
      this.tabPage4.Size = new System.Drawing.Size(317, 380);
      this.tabPage4.TabIndex = 3;
      this.tabPage4.Text = "Продать";
      this.tabPage4.UseVisualStyleBackColor = true;
      // 
      // textBox7
      // 
      this.textBox7.Location = new System.Drawing.Point(111, 207);
      this.textBox7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.textBox7.Name = "textBox7";
      this.textBox7.ReadOnly = true;
      this.textBox7.Size = new System.Drawing.Size(173, 20);
      this.textBox7.TabIndex = 54;
      // 
      // label38
      // 
      this.label38.AutoSize = true;
      this.label38.Location = new System.Drawing.Point(45, 209);
      this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label38.Name = "label38";
      this.label38.Size = new System.Drawing.Size(44, 13);
      this.label38.TabIndex = 53;
      this.label38.Text = "Скидка";
      // 
      // textBox6
      // 
      this.textBox6.Location = new System.Drawing.Point(138, 177);
      this.textBox6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.textBox6.Name = "textBox6";
      this.textBox6.ReadOnly = true;
      this.textBox6.Size = new System.Drawing.Size(146, 20);
      this.textBox6.TabIndex = 52;
      // 
      // label37
      // 
      this.label37.AutoSize = true;
      this.label37.Location = new System.Drawing.Point(45, 179);
      this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label37.Name = "label37";
      this.label37.Size = new System.Drawing.Size(92, 13);
      this.label37.TabIndex = 51;
      this.label37.Text = "Цена за единицу";
      // 
      // label36
      // 
      this.label36.AutoSize = true;
      this.label36.Location = new System.Drawing.Point(45, 275);
      this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label36.Name = "label36";
      this.label36.Size = new System.Drawing.Size(80, 13);
      this.label36.TabIndex = 49;
      this.label36.Text = "Дата продажи";
      // 
      // dateTimePicker3
      // 
      this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dateTimePicker3.Location = new System.Drawing.Point(138, 275);
      this.dateTimePicker3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.dateTimePicker3.Name = "dateTimePicker3";
      this.dateTimePicker3.Size = new System.Drawing.Size(139, 20);
      this.dateTimePicker3.TabIndex = 50;
      // 
      // textBox5
      // 
      this.textBox5.Location = new System.Drawing.Point(111, 237);
      this.textBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.textBox5.Name = "textBox5";
      this.textBox5.ReadOnly = true;
      this.textBox5.Size = new System.Drawing.Size(173, 20);
      this.textBox5.TabIndex = 48;
      // 
      // label34
      // 
      this.label34.AutoSize = true;
      this.label34.Location = new System.Drawing.Point(45, 239);
      this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label34.Name = "label34";
      this.label34.Size = new System.Drawing.Size(52, 13);
      this.label34.TabIndex = 47;
      this.label34.Text = "К оплате";
      // 
      // label33
      // 
      this.label33.AutoSize = true;
      this.label33.Location = new System.Drawing.Point(45, 116);
      this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label33.Name = "label33";
      this.label33.Size = new System.Drawing.Size(67, 13);
      this.label33.TabIndex = 46;
      this.label33.Text = "Покупатель";
      // 
      // comboBox18
      // 
      this.comboBox18.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox18.FormattingEnabled = true;
      this.comboBox18.Location = new System.Drawing.Point(116, 114);
      this.comboBox18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox18.Name = "comboBox18";
      this.comboBox18.Size = new System.Drawing.Size(163, 21);
      this.comboBox18.TabIndex = 45;
      this.comboBox18.SelectedIndexChanged += new System.EventHandler(this.comboBox18_SelectedIndexChanged);
      // 
      // label32
      // 
      this.label32.AutoSize = true;
      this.label32.Location = new System.Drawing.Point(45, 84);
      this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label32.Name = "label32";
      this.label32.Size = new System.Drawing.Size(57, 13);
      this.label32.TabIndex = 44;
      this.label32.Text = "Продавец";
      // 
      // comboBox17
      // 
      this.comboBox17.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox17.FormattingEnabled = true;
      this.comboBox17.Location = new System.Drawing.Point(107, 83);
      this.comboBox17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox17.Name = "comboBox17";
      this.comboBox17.Size = new System.Drawing.Size(173, 21);
      this.comboBox17.TabIndex = 43;
      // 
      // numericUpDown5
      // 
      this.numericUpDown5.Location = new System.Drawing.Point(116, 148);
      this.numericUpDown5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.numericUpDown5.Name = "numericUpDown5";
      this.numericUpDown5.Size = new System.Drawing.Size(159, 20);
      this.numericUpDown5.TabIndex = 42;
      this.numericUpDown5.ValueChanged += new System.EventHandler(this.numericUpDown5_ValueChanged);
      // 
      // label24
      // 
      this.label24.AutoSize = true;
      this.label24.Location = new System.Drawing.Point(45, 149);
      this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label24.Name = "label24";
      this.label24.Size = new System.Drawing.Size(66, 13);
      this.label24.TabIndex = 41;
      this.label24.Text = "Количество";
      // 
      // button6
      // 
      this.button6.Location = new System.Drawing.Point(48, 311);
      this.button6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.button6.Name = "button6";
      this.button6.Size = new System.Drawing.Size(230, 23);
      this.button6.TabIndex = 5;
      this.button6.Text = "Продать";
      this.button6.UseVisualStyleBackColor = true;
      this.button6.Click += new System.EventHandler(this.button6_Click);
      // 
      // label23
      // 
      this.label23.AutoSize = true;
      this.label23.Location = new System.Drawing.Point(45, 49);
      this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label23.Name = "label23";
      this.label23.Size = new System.Drawing.Size(37, 13);
      this.label23.TabIndex = 4;
      this.label23.Text = "Книга";
      // 
      // comboBox13
      // 
      this.comboBox13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox13.FormattingEnabled = true;
      this.comboBox13.Location = new System.Drawing.Point(85, 47);
      this.comboBox13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox13.Name = "comboBox13";
      this.comboBox13.Size = new System.Drawing.Size(195, 21);
      this.comboBox13.TabIndex = 3;
      this.comboBox13.SelectedIndexChanged += new System.EventHandler(this.comboBox13_SelectedIndexChanged);
      // 
      // tabPage5
      // 
      this.tabPage5.Controls.Add(this.numericUpDown6);
      this.tabPage5.Controls.Add(this.label25);
      this.tabPage5.Controls.Add(this.button7);
      this.tabPage5.Controls.Add(this.label26);
      this.tabPage5.Controls.Add(this.comboBox14);
      this.tabPage5.Location = new System.Drawing.Point(4, 22);
      this.tabPage5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.tabPage5.Name = "tabPage5";
      this.tabPage5.Size = new System.Drawing.Size(317, 380);
      this.tabPage5.TabIndex = 4;
      this.tabPage5.Text = "Списать";
      this.tabPage5.UseVisualStyleBackColor = true;
      // 
      // numericUpDown6
      // 
      this.numericUpDown6.Location = new System.Drawing.Point(117, 83);
      this.numericUpDown6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.numericUpDown6.Name = "numericUpDown6";
      this.numericUpDown6.Size = new System.Drawing.Size(159, 20);
      this.numericUpDown6.TabIndex = 47;
      // 
      // label25
      // 
      this.label25.AutoSize = true;
      this.label25.Location = new System.Drawing.Point(47, 84);
      this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label25.Name = "label25";
      this.label25.Size = new System.Drawing.Size(66, 13);
      this.label25.TabIndex = 46;
      this.label25.Text = "Количество";
      // 
      // button7
      // 
      this.button7.Location = new System.Drawing.Point(49, 120);
      this.button7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.button7.Name = "button7";
      this.button7.Size = new System.Drawing.Size(230, 19);
      this.button7.TabIndex = 45;
      this.button7.Text = "Списать";
      this.button7.UseVisualStyleBackColor = true;
      this.button7.Click += new System.EventHandler(this.button7_Click);
      // 
      // label26
      // 
      this.label26.AutoSize = true;
      this.label26.Location = new System.Drawing.Point(47, 54);
      this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label26.Name = "label26";
      this.label26.Size = new System.Drawing.Size(37, 13);
      this.label26.TabIndex = 44;
      this.label26.Text = "Книга";
      // 
      // comboBox14
      // 
      this.comboBox14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox14.FormattingEnabled = true;
      this.comboBox14.Location = new System.Drawing.Point(86, 52);
      this.comboBox14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox14.Name = "comboBox14";
      this.comboBox14.Size = new System.Drawing.Size(195, 21);
      this.comboBox14.TabIndex = 43;
      // 
      // tabPage6
      // 
      this.tabPage6.Controls.Add(this.numericUpDown8);
      this.tabPage6.Controls.Add(this.label29);
      this.tabPage6.Controls.Add(this.label28);
      this.tabPage6.Controls.Add(this.textBox4);
      this.tabPage6.Controls.Add(this.button8);
      this.tabPage6.Controls.Add(this.label27);
      this.tabPage6.Controls.Add(this.comboBox15);
      this.tabPage6.Location = new System.Drawing.Point(4, 22);
      this.tabPage6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.tabPage6.Name = "tabPage6";
      this.tabPage6.Size = new System.Drawing.Size(317, 380);
      this.tabPage6.TabIndex = 5;
      this.tabPage6.Text = "Добавить акцию";
      this.tabPage6.UseVisualStyleBackColor = true;
      // 
      // numericUpDown8
      // 
      this.numericUpDown8.Location = new System.Drawing.Point(140, 123);
      this.numericUpDown8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.numericUpDown8.Name = "numericUpDown8";
      this.numericUpDown8.Size = new System.Drawing.Size(141, 20);
      this.numericUpDown8.TabIndex = 52;
      // 
      // label29
      // 
      this.label29.AutoSize = true;
      this.label29.Location = new System.Drawing.Point(51, 123);
      this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label29.Name = "label29";
      this.label29.Size = new System.Drawing.Size(89, 13);
      this.label29.TabIndex = 51;
      this.label29.Text = "Процент скидки";
      // 
      // label28
      // 
      this.label28.AutoSize = true;
      this.label28.Location = new System.Drawing.Point(49, 96);
      this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label28.Name = "label28";
      this.label28.Size = new System.Drawing.Size(90, 13);
      this.label28.TabIndex = 50;
      this.label28.Text = "Название акции";
      // 
      // textBox4
      // 
      this.textBox4.Location = new System.Drawing.Point(140, 92);
      this.textBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.textBox4.Name = "textBox4";
      this.textBox4.Size = new System.Drawing.Size(142, 20);
      this.textBox4.TabIndex = 49;
      // 
      // button8
      // 
      this.button8.Location = new System.Drawing.Point(51, 172);
      this.button8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.button8.Name = "button8";
      this.button8.Size = new System.Drawing.Size(230, 19);
      this.button8.TabIndex = 48;
      this.button8.Text = "Добавить/изменить акцию";
      this.button8.UseVisualStyleBackColor = true;
      this.button8.Click += new System.EventHandler(this.button8_Click);
      // 
      // label27
      // 
      this.label27.AutoSize = true;
      this.label27.Location = new System.Drawing.Point(49, 59);
      this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label27.Name = "label27";
      this.label27.Size = new System.Drawing.Size(37, 13);
      this.label27.TabIndex = 47;
      this.label27.Text = "Книга";
      // 
      // comboBox15
      // 
      this.comboBox15.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox15.FormattingEnabled = true;
      this.comboBox15.Location = new System.Drawing.Point(88, 57);
      this.comboBox15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox15.Name = "comboBox15";
      this.comboBox15.Size = new System.Drawing.Size(195, 21);
      this.comboBox15.TabIndex = 46;
      this.comboBox15.SelectedIndexChanged += new System.EventHandler(this.comboBox15_SelectedIndexChanged);
      // 
      // tabPage7
      // 
      this.tabPage7.Controls.Add(this.label35);
      this.tabPage7.Controls.Add(this.comboBox19);
      this.tabPage7.Controls.Add(this.numericUpDown7);
      this.tabPage7.Controls.Add(this.label30);
      this.tabPage7.Controls.Add(this.button9);
      this.tabPage7.Controls.Add(this.label31);
      this.tabPage7.Controls.Add(this.comboBox16);
      this.tabPage7.Location = new System.Drawing.Point(4, 22);
      this.tabPage7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.tabPage7.Name = "tabPage7";
      this.tabPage7.Size = new System.Drawing.Size(317, 380);
      this.tabPage7.TabIndex = 6;
      this.tabPage7.Text = "Отложить";
      this.tabPage7.UseVisualStyleBackColor = true;
      // 
      // label35
      // 
      this.label35.AutoSize = true;
      this.label35.Location = new System.Drawing.Point(52, 86);
      this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label35.Name = "label35";
      this.label35.Size = new System.Drawing.Size(67, 13);
      this.label35.TabIndex = 49;
      this.label35.Text = "Покупатель";
      // 
      // comboBox19
      // 
      this.comboBox19.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox19.FormattingEnabled = true;
      this.comboBox19.Location = new System.Drawing.Point(123, 84);
      this.comboBox19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox19.Name = "comboBox19";
      this.comboBox19.Size = new System.Drawing.Size(163, 21);
      this.comboBox19.TabIndex = 48;
      // 
      // numericUpDown7
      // 
      this.numericUpDown7.Location = new System.Drawing.Point(123, 118);
      this.numericUpDown7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.numericUpDown7.Name = "numericUpDown7";
      this.numericUpDown7.Size = new System.Drawing.Size(159, 20);
      this.numericUpDown7.TabIndex = 47;
      // 
      // label30
      // 
      this.label30.AutoSize = true;
      this.label30.Location = new System.Drawing.Point(52, 119);
      this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label30.Name = "label30";
      this.label30.Size = new System.Drawing.Size(66, 13);
      this.label30.TabIndex = 46;
      this.label30.Text = "Количество";
      // 
      // button9
      // 
      this.button9.Location = new System.Drawing.Point(55, 155);
      this.button9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.button9.Name = "button9";
      this.button9.Size = new System.Drawing.Size(230, 19);
      this.button9.TabIndex = 45;
      this.button9.Text = "Отложить";
      this.button9.UseVisualStyleBackColor = true;
      this.button9.Click += new System.EventHandler(this.button9_Click);
      // 
      // label31
      // 
      this.label31.AutoSize = true;
      this.label31.Location = new System.Drawing.Point(52, 53);
      this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
      this.label31.Name = "label31";
      this.label31.Size = new System.Drawing.Size(37, 13);
      this.label31.TabIndex = 44;
      this.label31.Text = "Книга";
      // 
      // comboBox16
      // 
      this.comboBox16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboBox16.FormattingEnabled = true;
      this.comboBox16.Location = new System.Drawing.Point(91, 51);
      this.comboBox16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.comboBox16.Name = "comboBox16";
      this.comboBox16.Size = new System.Drawing.Size(195, 21);
      this.comboBox16.TabIndex = 43;
      // 
      // Form2
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(838, 428);
      this.Controls.Add(this.tabControl1);
      this.Controls.Add(this.dataGridView1);
      this.Controls.Add(this.groupBox2);
      this.Controls.Add(this.groupBox1);
      this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
      this.Name = "Form2";
      this.Text = "Книжный магазин";
      this.Load += new System.EventHandler(this.Form2_Load);
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
      this.tabControl1.ResumeLayout(false);
      this.tabPage1.ResumeLayout(false);
      this.tabPage1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
      this.tabPage2.ResumeLayout(false);
      this.tabPage2.PerformLayout();
      this.tabPage3.ResumeLayout(false);
      this.tabPage3.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      this.groupBox3.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
      this.tabPage4.ResumeLayout(false);
      this.tabPage4.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
      this.tabPage5.ResumeLayout(false);
      this.tabPage5.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
      this.tabPage6.ResumeLayout(false);
      this.tabPage6.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
      this.tabPage7.ResumeLayout(false);
      this.tabPage7.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.ComboBox comboBox1;
    private System.Windows.Forms.ComboBox comboBox2;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.DataGridView dataGridView1;
    private System.Windows.Forms.TabControl tabControl1;
    private System.Windows.Forms.TabPage tabPage1;
    private System.Windows.Forms.Button button4;
    private System.Windows.Forms.Label label21;
    private System.Windows.Forms.NumericUpDown numericUpDown3;
    private System.Windows.Forms.TextBox textBox3;
    private System.Windows.Forms.Label label12;
    private System.Windows.Forms.Label label20;
    private System.Windows.Forms.MaskedTextBox maskedTextBox3;
    private System.Windows.Forms.ComboBox comboBox11;
    private System.Windows.Forms.Label label13;
    private System.Windows.Forms.Label label19;
    private System.Windows.Forms.MaskedTextBox maskedTextBox4;
    private System.Windows.Forms.ComboBox comboBox10;
    private System.Windows.Forms.Label label14;
    private System.Windows.Forms.Label label18;
    private System.Windows.Forms.DateTimePicker dateTimePicker2;
    private System.Windows.Forms.ComboBox comboBox9;
    private System.Windows.Forms.Label label15;
    private System.Windows.Forms.Label label17;
    private System.Windows.Forms.NumericUpDown numericUpDown4;
    private System.Windows.Forms.ComboBox comboBox8;
    private System.Windows.Forms.Label label16;
    private System.Windows.Forms.TabPage tabPage2;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.ComboBox comboBox3;
    private System.Windows.Forms.TabPage tabPage3;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.Button button5;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label22;
    private System.Windows.Forms.NumericUpDown numericUpDown1;
    private System.Windows.Forms.ComboBox comboBox12;
    private System.Windows.Forms.TextBox textBox2;
    private System.Windows.Forms.NumericUpDown numericUpDown2;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label11;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label10;
    private System.Windows.Forms.MaskedTextBox maskedTextBox1;
    private System.Windows.Forms.ComboBox comboBox7;
    private System.Windows.Forms.ComboBox comboBox5;
    private System.Windows.Forms.DateTimePicker dateTimePicker1;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.MaskedTextBox maskedTextBox2;
    private System.Windows.Forms.ComboBox comboBox6;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.ComboBox comboBox4;
    private System.Windows.Forms.TabPage tabPage4;
    private System.Windows.Forms.Label label34;
    private System.Windows.Forms.Label label33;
    private System.Windows.Forms.ComboBox comboBox18;
    private System.Windows.Forms.Label label32;
    private System.Windows.Forms.ComboBox comboBox17;
    private System.Windows.Forms.NumericUpDown numericUpDown5;
    private System.Windows.Forms.Label label24;
    private System.Windows.Forms.Button button6;
    private System.Windows.Forms.Label label23;
    private System.Windows.Forms.ComboBox comboBox13;
    private System.Windows.Forms.TabPage tabPage5;
    private System.Windows.Forms.NumericUpDown numericUpDown6;
    private System.Windows.Forms.Label label25;
    private System.Windows.Forms.Button button7;
    private System.Windows.Forms.Label label26;
    private System.Windows.Forms.ComboBox comboBox14;
    private System.Windows.Forms.TabPage tabPage6;
    private System.Windows.Forms.Label label29;
    private System.Windows.Forms.Label label28;
    private System.Windows.Forms.TextBox textBox4;
    private System.Windows.Forms.Button button8;
    private System.Windows.Forms.Label label27;
    private System.Windows.Forms.ComboBox comboBox15;
    private System.Windows.Forms.TabPage tabPage7;
    private System.Windows.Forms.Label label35;
    private System.Windows.Forms.ComboBox comboBox19;
    private System.Windows.Forms.NumericUpDown numericUpDown7;
    private System.Windows.Forms.Label label30;
    private System.Windows.Forms.Button button9;
    private System.Windows.Forms.Label label31;
    private System.Windows.Forms.ComboBox comboBox16;
    private System.Windows.Forms.TextBox textBox5;
    private System.Windows.Forms.Label label36;
    private System.Windows.Forms.DateTimePicker dateTimePicker3;
    private System.Windows.Forms.TextBox textBox7;
    private System.Windows.Forms.Label label38;
    private System.Windows.Forms.TextBox textBox6;
    private System.Windows.Forms.Label label37;
    private System.Windows.Forms.NumericUpDown numericUpDown8;
  }
}