﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BookStore {
  public partial class Form2 : Form{
    public Form2() {
      InitializeComponent();
    }
    private void groupBox1_Enter(object sender, EventArgs e) {}
    private void Form2_Load(object sender, EventArgs e) { // формирование массива предустановленных запросов
      List<string> queries = new List<string>();
        queries.Add("Список новинок книг");
        queries.Add("Список самых продаваемых книг");
        queries.Add("Список самых популярных авторов");
        queries.Add("Список самых популярных жанров по итогам дня");
        queries.Add("Список самых популярных жанров по итогам недели");
        queries.Add("Список самых популярных жанров по итогам месяца");
        queries.Add("Список самых популярных жанров по итогам года");
      foreach (string item in queries) // заполнение выпадающего списка предустановленными запросами
        comboBox2.Items.Add(item);
      comboBox2.SelectedIndex = 0;
      List<string> findCriteria = new List<string>(); // формирование критериев поиска
        findCriteria.Add("по названию");
        findCriteria.Add("по автору");
        findCriteria.Add("по жанру");
      foreach (string item in findCriteria) // заполнение выпадающего списка критериями поиска
        comboBox1.Items.Add(item);
      comboBox1.SelectedIndex = 0;
      comboboxDataLoader();
    }
    private void comboboxDataLoader() { // предзаполнение выпадающих списков
      comboBox3.Items.Clear(); // предварительная очистка выпадающих списков
      comboBox4.Items.Clear();
      comboBox5.Items.Clear();
      comboBox6.Items.Clear();
      comboBox7.Items.Clear();
      comboBox8.Items.Clear();
      comboBox9.Items.Clear();
      comboBox10.Items.Clear();
      comboBox12.Items.Clear();
      comboBox13.Items.Clear();
      comboBox14.Items.Clear();
      comboBox15.Items.Clear();
      comboBox16.Items.Clear();
      comboBox17.Items.Clear();
      comboBox18.Items.Clear();
      comboBox19.Items.Clear();
      using (BookStoreEntities db = new BookStoreEntities()) {
        var authors = db.Authors.Select(x => x.AuthorName).ToList(); // авторы
        foreach (string item in authors) {
          comboBox11.Items.Add(item);
          comboBox5.Items.Add(item);
        }
        comboBox11.SelectedIndex = 0;
        comboBox5.SelectedIndex = 0;
        var publisher = db.Publishers.Select(x => x.PublisherName).ToList(); // издательства
        foreach (string item in publisher) {
          comboBox10.Items.Add(item);
          comboBox6.Items.Add(item);
        }
        comboBox10.SelectedIndex = 0;
        comboBox6.SelectedIndex = 0;
        var seller = db.Sellers.Select(x => x.SellerName).ToList(); // продавцы
        foreach (string item in seller)
          comboBox17.Items.Add(item);
        comboBox17.SelectedIndex = 0;
        var buyer = db.Buyers.Select(x => x.BuyerName).ToList(); // покупатели
        foreach (string item in buyer) {
          comboBox18.Items.Add(item);
          comboBox19.Items.Add(item);
        }
        comboBox18.SelectedIndex = 0;
        comboBox19.SelectedIndex = 0;
        var genres = db.Genres.Select(x => x.GenrerName).ToList(); // жанры
        foreach (string item in genres) {
          comboBox9.Items.Add(item);
          comboBox7.Items.Add(item);
        }
        comboBox9.SelectedIndex = 0;
        comboBox7.SelectedIndex = 0;
        comboBox8.Items.Insert(0, "NULL"); // добавление NULL и "" в комбо-боксы
        comboBox12.Items.Insert(0, "");
        var books = db.Books.Select(x => x.BookName).ToList(); // книги
        foreach (string item in books) {
          comboBox8.Items.Add(item);
          comboBox3.Items.Add(item);
          comboBox4.Items.Add(item);
          comboBox12.Items.Add(item);
          comboBox13.Items.Add(item);
          comboBox14.Items.Add(item);
          comboBox15.Items.Add(item);
          comboBox16.Items.Add(item);
        }
        comboBox8.SelectedIndex = 0;
        comboBox3.SelectedIndex = 0;
        comboBox4.SelectedIndex = 0;
        comboBox12.SelectedIndex = 0;
        comboBox13.SelectedIndex = 0;
        comboBox14.SelectedIndex = 0;
        comboBox15.SelectedIndex = 0;
        comboBox16.SelectedIndex = 0;
      }
    }
    private void button2_Click(object sender, EventArgs e) { // кнопка "Показать"
      using (BookStoreEntities db = new BookStoreEntities()) {
        var select = comboBox2.SelectedIndex;
        if (select != -1) {
          switch (select) {
            case 0:
              var result = db.Books.Where(x => x.PublishYear.Year == DateTime.Now.Year).Select(x => new { x.BookName, x.PublishYear, x.Authors.AuthorName, x.Publishers.PublisherName, x.Genres.GenrerName, Continue = x.Books2.BookName, x.Pages, x.Count, x.SellingPrice, x.CostPrice }).ToList();
              if (result.Count > 0)
                dataGridView1.DataSource = result;
              break;
            case 1:
              var result1 = db.Sales.Select(x => new { x.Books.BookName, x.Count }).GroupBy(x => x.BookName, x => x.Count).Select(x => new { Name = x.Key, Count = x.Sum() }).OrderByDescending(x => x.Count).ToList();
              if (result1.Count > 0)
                dataGridView1.DataSource = result1;
              break;
            case 2:
              var result2 = db.Sales.Select(x => new { x.Books.BookName, x.Books.Authors.AuthorName, x.Count }).GroupBy(x => x.AuthorName, x => x.Count).Select(x => new { Name = x.Key, Count = x.Sum() }).OrderByDescending(x => x.Count).ToList();
              if (result2.Count > 0)
                dataGridView1.DataSource = result2;
              break;
            case 3:
              var result3 = db.Sales.Where(x => x.SellDate.Day == DateTime.Now.Day).Select(x => new { x.Books.BookName, x.Books.Genres.GenrerName, x.Count }).GroupBy(x => x.GenrerName, x => x.Count).Select(x => new { Name = x.Key, Count = x.Sum() }).OrderByDescending(x => x.Count).ToList();
              if (result3.Count > 0)
                dataGridView1.DataSource = result3;
              break;
            case 4:
              var dateCriteria = DateTime.Now.Date.AddDays(-7);
              var result4 = db.Sales.Where(x => x.SellDate >= dateCriteria).Select(x => new { x.Books.BookName, x.Books.Genres.GenrerName, x.Count }).GroupBy(x => x.GenrerName, x => x.Count).Select(x => new { Name = x.Key, Count = x.Sum() }).OrderByDescending(x => x.Count).ToList();
              if (result4.Count > 0)
                dataGridView1.DataSource = result4;
              break;
            case 5:
              var dateCriteria2 = DateTime.Now.Date.AddMonths(-1);
              var result5 = db.Sales.Where(x => x.SellDate >= dateCriteria2).Select(x => new { x.Books.BookName, x.Books.Genres.GenrerName, x.Count }).GroupBy(x => x.GenrerName, x => x.Count).Select(x => new { Name = x.Key, Count = x.Sum() }).OrderByDescending(x => x.Count).ToList();
              if (result5.Count > 0)
                dataGridView1.DataSource = result5;
              break;
            case 6:
              var dateCriteria3 = DateTime.Now.Date.AddYears(-1);
              var result6 = db.Sales.Where(x => x.SellDate >= dateCriteria3).Select(x => new { x.Books.BookName, x.Books.Genres.GenrerName, x.Count }).GroupBy(x => x.GenrerName, x => x.Count).Select(x => new { Name = x.Key, Count = x.Sum() }).OrderByDescending(x => x.Count).ToList();
              if (result6.Count > 0)
                dataGridView1.DataSource = result6;
              break;
          }
        }
      }
    }
    private void button1_Click(object sender, EventArgs e) { // кнопка "Найти"
      using (BookStoreEntities db = new BookStoreEntities()) {
        var select = comboBox1.SelectedIndex;
        var value = textBox1.Text;
        dataGridView1.DataSource = null;
        if (select != -1) {
          switch (select) {
            case 0:
              var result = db.Books.Where(x => x.BookName.Contains(value)).Select(x => new { x.BookName, x.PublishYear, x.Authors.AuthorName, x.Genres.GenrerName, x.Publishers.PublisherName, Continue = x.Books2.BookName, x.Pages, x.Count, x.SellingPrice, x.CostPrice }).ToList();
              if (result.Count > 0)
                dataGridView1.DataSource = result;
              break;
            case 1:
              var result1 = db.Books.Where(x => x.Authors.AuthorName.Contains(value)).Select(x => new { x.BookName, x.PublishYear, x.Authors.AuthorName, x.Genres.GenrerName, x.Publishers.PublisherName, Continue = x.Books2.BookName, x.Pages, x.Count, x.SellingPrice, x.CostPrice }).ToList();
              if (result1.Count > 0)
                dataGridView1.DataSource = result1;
              break;
            case 2:
              var result2 = db.Books.Where(x => x.Genres.GenrerName.Contains(value)).Select(x => new { x.BookName, x.PublishYear, x.Authors.AuthorName, x.Genres.GenrerName, x.Publishers.PublisherName, Continue = x.Books2.BookName, x.Pages, x.Count, x.SellingPrice, x.CostPrice }).ToList();
              if (result2.Count > 0)
                dataGridView1.DataSource = result2;
              break;
          }
        }
      }
    }
    private void button4_Click(object sender, EventArgs e) { // кнопка "Сохранить" при добавлении книги
      if (
        textBox3.Text != String.Empty
        && comboBox11.SelectedIndex != -1
        && comboBox10.SelectedIndex != -1
        && comboBox9.SelectedIndex != -1
        && comboBox8.SelectedIndex != -1
        && numericUpDown4.Value > 0
        && dateTimePicker2.Value != null
        && numericUpDown3.Value > 0
        && maskedTextBox4.Text != String.Empty
        && maskedTextBox3.Text != String.Empty) {
        using (BookStoreEntities db = new BookStoreEntities()) {
          var newBook = new Books() {
            BookName = textBox3.Text,
            Authors_Id = db.Authors.Where(x => x.AuthorName == comboBox11.SelectedItem.ToString()).Select(x => x.Id).FirstOrDefault(),
            Publishers_Id = db.Publishers.Where(x => x.PublisherName == comboBox10.SelectedItem.ToString()).Select(x => x.Id).FirstOrDefault(),
            Genres_Id = db.Genres.Where(x => x.GenrerName == comboBox9.SelectedItem.ToString()).Select(x => x.Id).FirstOrDefault(),
            ContinueBook_Id = (comboBox8.SelectedItem.ToString() == "NULL")
              ?(int?)null
              :db.Books.Where(x => x.BookName == comboBox8.SelectedItem.ToString()).Select(x => x.Id).FirstOrDefault(),
            Pages = int.Parse(numericUpDown4.Value.ToString()),
            PublishYear = dateTimePicker2.Value,
            Count = int.Parse(numericUpDown3.Value.ToString()),
            CostPrice = decimal.Parse(maskedTextBox4.Text.ToString()),
            SellingPrice = decimal.Parse(maskedTextBox3.Text.ToString())
          };
          var book = db.Books.Where(x => x.BookName == newBook.BookName).FirstOrDefault();
          if (book == null) {
            db.Books.Add(newBook);
            db.SaveChanges();
            MessageBox.Show("Книга " + newBook.BookName + " добавлена", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
          }
          else
            MessageBox.Show("Кинга с таким именем уже существует", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
      }
      comboboxDataLoader();
    }
    private void button3_Click(object sender, EventArgs e) { // кнопка "Удалить" при удалении книги
      if (comboBox3.SelectedIndex != -1) {
        using (BookStoreEntities db = new BookStoreEntities()) {
          var book = db.Books.Where(x => x.BookName == comboBox3.SelectedItem.ToString()).FirstOrDefault();
          if (book != null) {
            db.Books.Remove(book);
            db.SaveChanges();
            MessageBox.Show("Книга " + book.BookName + " удалена", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
          }
          else
            MessageBox.Show("Книга с таким именем не существует", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
      }
      comboboxDataLoader();
    }
    private void comboBox4_SelectedIndexChanged(object sender, EventArgs e) { // выбор книги во вкладе "Редактирование" книги
      using (BookStoreEntities db = new BookStoreEntities()) {
        textBox2.Text = comboBox4.SelectedItem.ToString();
        comboBox5.SelectedItem = db.Books.Where(x => x.BookName == comboBox4.SelectedItem.ToString()).Select(x => x.Authors.AuthorName).FirstOrDefault();
        comboBox6.SelectedItem = db.Books.Where(x => x.BookName == comboBox4.SelectedItem.ToString()).Select(x => x.Publishers.PublisherName).FirstOrDefault();
        comboBox7.SelectedItem = db.Books.Where(x => x.BookName == comboBox4.SelectedItem.ToString()).Select(x => x.Genres.GenrerName).FirstOrDefault();
        comboBox12.SelectedItem = db.Books.Where(x => x.BookName == comboBox4.SelectedItem.ToString()).Select(x => x.Books2.BookName).FirstOrDefault();
      }
    }
    private void button5_Click(object sender, EventArgs e) { // кнопка "Сохранить" при редактировании книг
      if (
        textBox2.Text != String.Empty
        && comboBox5.SelectedItem.ToString() != String.Empty
        && comboBox6.SelectedItem.ToString() != String.Empty
        && comboBox7.SelectedItem.ToString() != String.Empty
        && numericUpDown2.Value > 0
        && dateTimePicker1.Value != null
        && numericUpDown1.Value > 0
        && maskedTextBox2.Text != String.Empty
        && maskedTextBox1.Text != String.Empty) {
        using (BookStoreEntities db = new BookStoreEntities()) {
          var book = db.Books.Where(x => x.BookName == comboBox4.SelectedItem.ToString()).FirstOrDefault();
          if (book != null) {
            book.BookName = textBox2.Text;
            book.Authors_Id = db.Authors.Where(x => x.AuthorName == comboBox5.SelectedItem.ToString()).Select(x => x.Id).FirstOrDefault();
            book.Publishers_Id = db.Publishers.Where(x => x.PublisherName == comboBox6.SelectedItem.ToString()).Select(x => x.Id).FirstOrDefault();
            book.Genres_Id = db.Genres.Where(x => x.GenrerName == comboBox7.SelectedItem.ToString()).Select(x => x.Id).FirstOrDefault();
            book.ContinueBook_Id = (comboBox12.SelectedItem.ToString() == "")
              ?(int?)null
              :db.Books.Where(x => x.BookName == comboBox12.SelectedItem.ToString()).Select(x => x.Id).FirstOrDefault();
            book.Pages = int.Parse(numericUpDown2.Value.ToString());
            book.PublishYear = dateTimePicker1.Value;
            book.Count = int.Parse(numericUpDown1.Value.ToString());
            book.CostPrice = decimal.Parse(maskedTextBox2.Text.ToString());
            book.SellingPrice = decimal.Parse(maskedTextBox1.Text.ToString());
            db.SaveChanges();
            MessageBox.Show("Книга " + book.BookName + " обновлена", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
          }
          else
            MessageBox.Show("Книга с таким именем не существует", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
      }
      else
        MessageBox.Show("Не все поля заполнены корректно", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
      comboboxDataLoader();
    }
    private void button6_Click(object sender, EventArgs e) {  // кнопка "Продать" при продаже книги
      if (
        comboBox13.SelectedIndex != -1
        && comboBox17.SelectedIndex != -1
        && comboBox18.SelectedIndex != -1
        && numericUpDown5.Value > 0) {
        using (BookStoreEntities db = new BookStoreEntities()) {
          var book = db.Books.Where(x => x.BookName == comboBox13.SelectedItem.ToString()).FirstOrDefault();
          var seller = db.Sellers.Where(x => x.SellerName == comboBox17.SelectedItem.ToString()).FirstOrDefault();
          var buyer = db.Buyers.Where(x => x.BuyerName == comboBox18.SelectedItem.ToString()).FirstOrDefault();
          var discount = db.Stocks.Where(x => x.Books_Id == book.Id).Select(x => x.StockPercent).FirstOrDefault();
          var totalPrice = (book.SellingPrice - (book.SellingPrice * discount)) * int.Parse(numericUpDown5.Value.ToString());
          var newSale = new Sales() {
            Books_Id = book.Id,
            Sellers_Id = seller.Id,
            Buyers_Id = buyer.Id,
            Count = int.Parse(numericUpDown5.Value.ToString()),
            SellDate = dateTimePicker3.Value,
            TotalPrice = totalPrice
          };
          if (book.Count >= newSale.Count) {
            db.Sales.Add(newSale);
            book.Count -= newSale.Count;
            db.SaveChanges();
            MessageBox.Show("Книга " + newSale.Books.BookName + " продана " + newSale.Buyers.BuyerName + " продавцом " + newSale.Sellers.SellerName, "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
          }
          else
            MessageBox.Show("Недостаточно книг для продажи", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
      }
      comboboxDataLoader();
    }
    private void comboBox13_SelectedIndexChanged(object sender, EventArgs e) { // выбор книги во вкладе "Продажи"
      using (BookStoreEntities db = new BookStoreEntities()) {
        var book = db.Books.Where(x => x.BookName == comboBox13.SelectedItem.ToString()).FirstOrDefault();
        textBox6.Text = book.SellingPrice.ToString();
        textBox7.Text = (db.Stocks.Where(x => x.Books_Id == book.Id).Select(x => x.StockPercent).FirstOrDefault() * 100).ToString();
        textBox5.Text = 0.ToString();
        numericUpDown5.Value = 0;
      }
    }
    private void numericUpDown5_ValueChanged(object sender, EventArgs e) { // счетчик количества книг во вкладе "Продажи" 
      if (textBox6.Text != String.Empty && textBox7.Text != String.Empty)
        textBox5.Text = ((decimal.Parse(textBox6.Text) - (decimal.Parse(textBox6.Text) * decimal.Parse(textBox7.Text) / 100)) * decimal.Parse(numericUpDown5.Value.ToString())).ToString();
    }
    private void button7_Click(object sender, EventArgs e) { // кнопка "Списать"
      if (comboBox14.SelectedIndex != -1 && numericUpDown6.Value > 0) {
        using (BookStoreEntities db = new BookStoreEntities()) {
          var book = db.Books.Where(x => x.BookName == comboBox14.SelectedItem.ToString()).FirstOrDefault();
          if (book != null && book.Count >= int.Parse(numericUpDown6.Value.ToString())) {
            book.Count -= int.Parse(numericUpDown6.Value.ToString());
            db.SaveChanges();
            MessageBox.Show("Списано " + numericUpDown6.Value.ToString() + " книг", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
          }
          else
            MessageBox.Show("Количество книг на списание не может превышать общее количество книг", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
      }
      comboboxDataLoader();
    }
    private void comboBox15_SelectedIndexChanged(object sender, EventArgs e) { // выбор книги во вкладе "Добавить акцию"
      using (BookStoreEntities db = new BookStoreEntities()) {
        var book = db.Books.Where(x => x.BookName == comboBox15.SelectedItem.ToString()).FirstOrDefault();
        var stock = db.Stocks.Where(x => x.Books_Id == book.Id).FirstOrDefault();
        textBox4.Text = stock != null ? stock.StockName : null;
        numericUpDown8.Value = stock != null ? stock.StockPercent * 100 : 0;
      }
    }
    private void button8_Click(object sender, EventArgs e) { // кнопка "Добавить/изменить акцию"
      if (comboBox15.SelectedIndex != -1 && textBox4.Text != String.Empty && numericUpDown8.Value > 0) {
        using (BookStoreEntities db = new BookStoreEntities()) {
          var book = db.Books.Where(x => x.BookName == comboBox15.SelectedItem.ToString()).FirstOrDefault();
          var stock = db.Stocks.Where(x => x.Books_Id == book.Id).FirstOrDefault();
          if (stock != null) {
            stock.Books_Id = book.Id;
            stock.StockPercent = decimal.Parse(numericUpDown8.Value.ToString()) / 100;
            stock.StockName = textBox4.Text;
            db.SaveChanges();
            MessageBox.Show("Акция " + stock.StockName + " изменена", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
          }
          else {
            var newStock = new Stocks() {
              Books_Id = book.Id,
              StockPercent = decimal.Parse(numericUpDown8.Value.ToString()) / 100,
              StockName = textBox4.Text
            };
            db.Stocks.Add(newStock);
            db.SaveChanges();
            MessageBox.Show("Акция " + newStock.StockName + " добавлена", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
          }
        }
      }
      else
        MessageBox.Show("Не все поля заполнены корректно", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
      comboboxDataLoader();
    }
    private void button9_Click(object sender, EventArgs e) { // кнопка "Отложить"
      if (comboBox16.SelectedIndex != -1 && comboBox19.SelectedIndex != -1 && numericUpDown7.Value > 0) {
        using (BookStoreEntities db = new BookStoreEntities()) {
          var book = db.Books.Where(x => x.BookName == comboBox16.SelectedItem.ToString()).FirstOrDefault();
          var buyer = db.Buyers.Where(x => x.BuyerName == comboBox19.SelectedItem.ToString()).FirstOrDefault();
          if (book != null && buyer != null && book.Count >= int.Parse(numericUpDown7.Value.ToString())) {
            var newReserve = new Reserves() {
              Books_Id = book.Id,
              Buyers_Id = buyer.Id,
              Count = int.Parse(numericUpDown7.Value.ToString())
            };
            db.Reserves.Add(newReserve);
            book.Count -= int.Parse(numericUpDown7.Value.ToString());
            db.SaveChanges();
            MessageBox.Show("Отложено " + numericUpDown7.Value.ToString() + " книг для покупателя " + buyer.BuyerName, "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
          }
          else
            MessageBox.Show("Количество книг на резерв не может превышать общее количество книг", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
      }
      else
        MessageBox.Show("Не все поля заполнены корректно", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
      comboboxDataLoader();
    }
    private void comboBox18_SelectedIndexChanged(object sender, EventArgs e) {}
  }
}

/*I. Создание базы данных:
«Главное меню» -> «Вид» -> «Обозреватель объектов SQL Server» -> щелчок по узлу SQL Server -> 
щелчок по узлу (localdb)\MSSQLLocalDB -> «Базы данных» (щелчок правой кнопкой) -> «Добавить новую 
базу данных» -> изменить имя на BookStore -> кнопка «OK» -> щелчок правой кнопкой по созданной базе -> 
«Создать запрос…» -> в открывшуюся вкладку вставить скрипт:

DROP DATABASE IF EXISTS BookStore;
CREATE DATABASE BookStore; 
USE BookStore;
DROP TABLE IF EXISTS Authors;
CREATE TABLE Authors(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 AuthorName NVARCHAR(255) NOT NULL,
);
DROP TABLE IF EXISTS Publishers;
CREATE TABLE Publishers(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 PublisherName NVARCHAR(255) NOT NULL,
);
DROP TABLE IF EXISTS Genres;
CREATE TABLE Genres(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 GenrerName NVARCHAR(255) NOT NULL,
);
DROP TABLE IF EXISTS Books;
CREATE TABLE Books(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 BookName NVARCHAR(255) NOT NULL,
 Authors_Id INT NOT NULL FOREIGN KEY REFERENCES Authors(Id) ON DELETE CASCADE,
 Publishers_Id INT NOT NULL FOREIGN KEY REFERENCES Publishers(Id) ON DELETE CASCADE,
 Genres_Id INT NOT NULL FOREIGN KEY REFERENCES Genres(Id) ON DELETE CASCADE,
 ContinueBook_Id INT NULL FOREIGN KEY REFERENCES Books(Id) ON DELETE NO ACTION,
 Pages int NOT NULL,
 PublishYear Date NOT NULL,
 CostPrice Money NOT NULL,
 SellingPrice Money NOT NULL,
 Count  int NOT NULL,
);
DROP TABLE IF EXISTS Sellers;
CREATE TABLE Sellers(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 SellerName NVARCHAR(255) NOT NULL,
);
DROP TABLE IF EXISTS Buyers;
CREATE TABLE Buyers(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 BuyerName NVARCHAR(255) NOT NULL,
);
DROP TABLE IF EXISTS Sales;
CREATE TABLE Sales(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 Books_Id INT NOT NULL FOREIGN KEY REFERENCES Books(Id) ON DELETE CASCADE,
 Sellers_Id INT NOT NULL FOREIGN KEY REFERENCES Sellers(Id) ON DELETE CASCADE,
 Buyers_Id INT NOT NULL FOREIGN KEY REFERENCES Buyers(Id) ON DELETE CASCADE,
 Count  int NOT NULL,
 TotalPrice Money NOT NULL,
 SellDate Date NOT NULL,
);
DROP TABLE IF EXISTS Reserves;
CREATE TABLE Reserves(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 Books_Id INT NOT NULL FOREIGN KEY REFERENCES Books(Id) ON DELETE CASCADE,
 Buyers_Id INT NOT NULL FOREIGN KEY REFERENCES Buyers(Id) ON DELETE CASCADE,
 Count  int NOT NULL,
);
DROP TABLE IF EXISTS Substracts;
CREATE TABLE Substracts(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 Books_Id INT NOT NULL FOREIGN KEY REFERENCES Books(Id) ON DELETE CASCADE,
 Count  int NOT NULL,
);
DROP TABLE IF EXISTS Stocks;
CREATE TABLE Stocks(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 Books_Id INT NOT NULL FOREIGN KEY REFERENCES Books(Id) ON DELETE CASCADE,
 StockName NVARCHAR(255) NOT NULL,
 StockPercent DECIMAL(3, 2) NOT NULL,
);
DROP TABLE IF EXISTS Users;
CREATE TABLE Users(
 Id INT NOT NULL IDENTITY(1,1) PRIMARY KEY,
 UserName NVARCHAR(255) NOT NULL,
 Password NVARCHAR(255) NOT NULL,
);

insert into Authors(AuthorName) values (N'Достоевский Ф.М.');
insert into Authors(AuthorName) values (N'Пушкин А.А.');
insert into Authors(AuthorName) values (N'Толстой Л.Н.');
insert into Authors(AuthorName) values (N'Чехов А.П.');
insert into Authors(AuthorName) values (N'Гоголь Н.В.');
insert into Authors(AuthorName) values (N'Булгаков М.А.');
insert into Authors(AuthorName) values (N'Гинг С.');
insert into Authors(AuthorName) values (N'Чейз Д.Х.');
insert into Authors(AuthorName) values (N'Агата К.М.');
insert into Authors(AuthorName) values (N'Брэдбери Р.Д.');

insert into Publishers(PublisherName) values (N'Литрес');
insert into Publishers(PublisherName) values (N'Нижполиграф');
insert into Publishers(PublisherName) values (N'Просвещение');

insert into Genres(GenrerName) values (N'Зарубежная классика');
insert into Genres(GenrerName) values (N'Сказки');
insert into Genres(GenrerName) values (N'Русская литература');
insert into Genres(GenrerName) values (N'Зарубежные детективы');
insert into Genres(GenrerName) values (N'Зарубежная фантастика');
insert into Genres(GenrerName) values (N'Поэзия');

insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Идиот', 1, 1, 1, null, 843, '01-01-2016', 5500, 12, 7500);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Стихи Пушкина, том 1', 2, 6, 2, null, 358, '01-01-2012', 4300, 8, 6400);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Война и мир, том 1', 3, 3, 3, null, 534, '01-01-2020', 7600, 16, 8600);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Хамелеон', 4, 3, 1, null, 654, '01-01-2008', 3590, 16, 8600);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Ревизор', 5, 3, 2, null, 487, '01-01-2011', 6100, 14, 7800);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Мастер и маргарита', 6, 3, 3, null, 533, '01-01-2010', 4700, 11, 6300);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Оно', 7, 4, 1, null, 763, '01-01-2004', 8200, 18, 9800);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Запах золота', 8, 4, 2, null, 564, '01-01-2006', 7350, 15, 8650);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Десять нигретят', 9, 4, 3, null, 762, '01-01-2018', 4700, 6, 6400);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Горизонты фантастики', 10, 5, 1, null, 537, '01-01-2014', 5300, 7, 7700);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Сказки Пушкина', 2, 2, 2, null, 426, '01-01-2002', 3300, 5, 5200);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Стихи Пушкина, том 2', 2, 6, 2, 2, 432, '01-01-2013', 4400, 9, 6500);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Стихи Пушкина, том 3', 2, 6, 2, 2, 324, '01-01-2014', 4500, 10, 6600);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Война и мир, том 2', 3, 3, 3, 3, 343, '01-01-2021', 7700, 17, 8700);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Война и мир, том 3', 3, 3, 3, 3, 443, '01-01-2022', 7800, 18, 8800);
insert into Books(BookName, Authors_Id, Genres_Id, Publishers_Id, ContinueBook_Id, Pages, PublishYear, CostPrice, Count, SellingPrice) 
values (N'Оно 2', 7, 4, 1, 7, 654, '01-01-2005', 8300, 19, 9900);

insert into Sellers(SellerName) values (N'Иванов И.И.');
insert into Sellers(SellerName) values (N'Петров П.П.');
insert into Sellers(SellerName) values (N'Сидоров С.С.');

insert into Buyers(BuyerName) values (N'Омаров О.О.');
insert into Buyers(BuyerName) values (N'Ахметов А.А.');
insert into Buyers(BuyerName) values (N'Абаев А.А.');

insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (1, 1, 1, 1, 1000, '25-07-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (1, 2, 2, 2, 1000, '25-07-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (1, 3, 3, 3, 1000, '25-07-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (3, 3, 3, 3, 3000, '23-07-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (1, 1, 1, 4, 4000, '22-07-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (2, 2, 2, 5, 5000, '21-07-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (2, 1, 1, 1, 2000, '26-06-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (2, 2, 2, 2, 2000, '27-06-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (2, 3, 3, 3, 2000, '28-06-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (2, 1, 1, 1, 2000, '21-06-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (2, 2, 2, 2, 2000, '21-06-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (2, 3, 3, 3, 2000, '21-06-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (3, 3, 3, 3, 3000, '20-05-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (1, 1, 1, 4, 4000, '19-04-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (2, 2, 2, 5, 5000, '18-03-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (3, 3, 3, 6, 6000, '17-02-2022');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (1, 1, 1, 7, 7000, '16-01-2021');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (2, 2, 2, 8, 8000, '15-12-2021');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (3, 3, 3, 9, 9000, '14-11-2021');
insert into Sales(Books_Id, Sellers_Id, Buyers_Id, Count, TotalPrice, SellDate) values (1, 1, 1, 10, 10000, '13-10-2021');

insert into Stocks(Books_Id, StockName, StockPercent) values (1, N'к 1 сентября', 0.12);
insert into Stocks(Books_Id, StockName, StockPercent) values (2, N'к дню конституции', 0.10);
insert into Stocks(Books_Id, StockName, StockPercent) values (3, N'к дню независимости', 0.16);
insert into Stocks(Books_Id, StockName, StockPercent) values (4, N'к новому году', 0.5);
insert into Stocks(Books_Id, StockName, StockPercent) values (4, N'к наурызу', 0.7);

-> кнопка «Выполнить» (квадратная в ней нарисован треугольник) -> закрыть вкладку
Примечание:
Если «Вид» не содержит «Обозреватель объектов SQL Server»: в «Обозревателе решений» щелчок правой кнопкой 
по наименованию проекта -> «Добавить» -> «Создать элемент…» -> «База данных, основанная на службах» 
-> кнопка «Добавить»
Если в «Обозревателе решений» нет элемента «База данных, основанная на службах», тогда «Главное меню» 
-> «Вид» -> «Обозреватель серверов» -> в открывшейся вкладке щелчок правой кнопкой по «Подключения 
SharePoint» -> «Добавить подключение…» -> Visual Studio попытается самостоятельно установить 
«Обозреватель объектов SQL Server»

II. Установка соединения: 
«Главное меню» -> «Вид» -> «Обозреватель серверов» -> щелчок по опции «Подключение данных» -> в контекстном меню 
выбрать «Добавить подключение…» -> поле «Источник данных» должно содержать: Microsoft SQL Server (SqlClient), 
в поле «Имя сервера» внести: (localdb)\MSSQLLocalDB -> в поле «Выберите или введите имя базы данных» выбрать: 
BookStore -> нажать кнопку «OK»
Если не получается подключиться изменить код в App.config (расположен в окне обозревателя решений) 
– удалить весь текст после <add name="BookStoreEntities" и добавить: 
    connectionString="Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=BookStore;Integrated Security=True;
    Encrypt=False" providerName="System.Data.SqlClient" />
    </connectionStrings>
</configuration>
 
ПРИМЕЧАНИЕ: Для корректного распознавания внешних ключей Entity Framework рекомендуется синтаксис, 
реализованный в скрипте базы данных: НаиаенованиеТаблицы_Id, например: Authors_Id*/

/*Задание. Создать приложение «Книжный магазин».
Основная задача проекта: учитывать текущий ассортимент книг в магазине.
Необходимо хранить следующую информацию о книгах: название книги, ФИО автора, название издательства, 
количество страниц, жанр, год издания, себестоимость, цена для продажи, является ли книга продолжением 
какой-то другой книги (например, вторая часть дилогии).
Приложение должно позволять: добавлять книги, удалять книги, редактировать параметры книг, продавать книги, 
списывать книги, вносить книги в акции (например, неделя книг новогодней тематики со скидкой 10%), 
откладывать книги для конкретного покупателя.
Приложение должно предоставить функциональность по поиску книг по таким параметрам: название книги, автор, 
жанр. Приложение должно предоставлять возможность просмотреть список новинок, список самых продаваемых книг, 
список самых популярных авторов, список самых популярных жанров по итогам дня, недели, месяца, года.
Необходимо предусмотреть возможность входа по логину и паролю.*/