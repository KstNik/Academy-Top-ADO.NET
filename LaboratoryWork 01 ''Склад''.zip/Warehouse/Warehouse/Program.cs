﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace Warehouse {
    class Program {
        SqlConnection conn = null;
        public Program() {
            conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;
                Initial Catalog=Warehouse;Integrated Security=SSPI;";
        }
        static void Main(string[] args) {

            Console.WriteLine("\n\t\tПРИСОЕДИНЁННЫЙ РЕЖИМ");

            Program pr = new Program();
            pr.ReadData();
        }
        public void ReadData() {
            SqlDataReader rdr = null;
            int num = -1;
            String[] str = { "Отображение всей информации о товаре", "Товары категории c id = 1",
                "Товары поставщика с id = 2", "Cреднее количество товаров по каждому типу товара", 
                "Типы товаров", "Поставщики", "Товар с максимальным количеством",
                "Товар с минимальным количеством", "Товар с минимальной себестоимостью",
                "Товар с максимальной себестоимостью", "Самый старый товар" };
            try { // открытие соединения
                conn.Open();
                Console.WriteLine("\n  Соединение с сервером установлено");
                SqlCommand cmd = new SqlCommand("SELECT * FROM Warehouse; SELECT * FROM Warehouse WHERE [TypeId] = 1; " +
                    "SELECT * FROM Warehouse WHERE [SupId] = 2; SELECT [TypeId], AVG([Quant]) AS AvgQuant FROM Warehouse GROUP BY [TypeId]; " +
                    "SELECT * FROM [Type]; SELECT * FROM [Supplier]; SELECT [Name] FROM Warehouse WHERE [Quant] = (SELECT MAX([Quant]) FROM Warehouse); " +
                    "SELECT [Name] FROM Warehouse WHERE [Quant] = (SELECT MIN([Quant]) FROM Warehouse); " +
                    "SELECT [Name] FROM Warehouse WHERE [Price] = (SELECT MIN([Price]) FROM Warehouse); " +
                    "SELECT [Name] FROM Warehouse WHERE [Price] = (SELECT MAX([Price]) FROM Warehouse); " +
                    "SELECT [Name] FROM Warehouse WHERE [Date] = (SELECT MIN([Date]) FROM Warehouse)", conn);
                rdr = cmd.ExecuteReader();
                int line; // извлечение полученных строк
                do {
                    num++;
                    Console.WriteLine("\n" + "\t" + (num + 1) + ". " + str[num]);
                    line = 0;
                    while (rdr.Read()) {
                        if (line == 0) { // формирование шапки таблицы перед выводом первой строки
                            Console.Write("  ");
                            for (int i = 0; i < rdr.FieldCount; i++) // цикл по числу прочитанных полей
                                Console.Write(rdr.GetName(i).ToString() + "\t"); // вывод в консольное окно имён полей
                            Console.WriteLine();
                        }
                        line++;
                        Console.Write("  ");
                        if (num <= 2) Console.WriteLine(rdr[0] + "\t" + rdr[1] + "\t" + rdr[2] + "\t"
                            + rdr[3] + "\t" + rdr[4] + "\t" + rdr[5] + "\t" + rdr[6]);
                        else if (num == 3) Console.WriteLine(rdr[0] + "\t\t" + rdr[1]);
                        else if ((num == 4) || (num == 5)) Console.WriteLine(rdr[0] + "\t" + rdr[1]);
                        else Console.WriteLine(rdr[0]);
                    }
                    Console.WriteLine("  Обработано строк: " + line.ToString());
                } while (rdr.NextResult());
            }
            catch (Exception ex) {
                Console.WriteLine("  Ошибка: " + ex.Message);
            }
            finally {
                if (rdr != null) // закрытие reader
                    rdr.Close();
                if (conn != null) // закрытие соединения
                    conn.Close();
            }

            Console.Write("\n  Для выхода нажмите любую клавишу ");
            Console.ReadKey();
        }
    }
}

/*Создание базы данных:
«Главное меню» -> «Вид» -> «Обозреватель объектов SQL Server» -> щелчок по узлу SQL Server -> 
щелчок по узлу (localdb)\MSSQLLocalDB -> «Базы данных» (щелчок правой кнопкой) -> 
«Добавить новую базу данных» -> изменить имя (указано ниже в [] после CREATE TABLE [dbo].) -> 
кнопка «OK» -> щелчок по узлу созданной базы -> «Таблицы» (щелчок правой кнопкой) -> «Добавить новую 
таблицу» -> вставить скрипт:
CREATE TABLE [dbo].[Type] (
    [Id]       INT           IDENTITY (1, 1) NOT NULL,
    [TypName] NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
GO
CREATE TABLE [dbo].[Supplier] (
    [Id]           INT           IDENTITY (1, 1) NOT NULL,
    [SupName] NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
GO
CREATE TABLE [dbo].[Warehouse] (
    [Id]         INT           IDENTITY (1, 1) NOT NULL,
    [Name]       NVARCHAR (50) NOT NULL,
    [TypeId]     INT           NOT NULL,
    [SupId] INT           NOT NULL,
    [Quant]   INT           DEFAULT ((0)) NOT NULL,
    [Price]      INT           DEFAULT ((100)) NOT NULL,
    [Date]       DATE          DEFAULT (getdate()) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([TypeId]) REFERENCES [dbo].[Type] ([Id]),
    FOREIGN KEY ([SupId]) REFERENCES [dbo].[Supplier] ([Id])
);
 -> кнопка «Обновить» -> кнопка «Обновить базу данных» -> щелчок правой кнопкой по созданной таблице -> 
«Просмотр данных» -> заполнить базу (при необходимости)
ДЛЯ КОРРЕКТНОГО ОТОБРАЖЕНИЯ В КОНСОЛИ КОЛИЧЕСТВО СИМВОЛОВ В ЯЧЕЙКЕ НЕ ДОЛЖНО ПРЕВЫШАТЬ 7!!!
Пример заполнения:
    Таблица "Type"
| Id | TypName|
|  1 | Одежда |
|  2 | Обувь  |
    Таблица "Supplier"
| Id | SupName|
|  1 | Стиль  |
|  2 | Путь   |
    Таблица "Warehouse"
| Id |  Name  | TypeId |  SupId |  Quant |  Price |   Date   |
|  1 | Брюки  |    1   |    1   |    2   |  1000  |2024-01-01|
|  2 | Джинсы |    1   |    1   |    1   |  2000  |2024-01-02|
|  3 | Туфли  |    2   |    2   |    4   |  3000  |2024-01-03|
|  4 | Ботинки|    2   |    2   |    3   |  4000  |2024-01-04|

Примечание: Если «Вид» не содержит «Обозреватель объектов SQL Server»: в «Обозревателе 
решений» щелчок правой кнопкой по наименованию проекта -> «Добавить» -> «Создать элемент …» -> 
«База данных, основанная на службах» -> кнопка «Добавить»*/